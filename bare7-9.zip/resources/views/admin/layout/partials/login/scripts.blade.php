<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="{{ asset('adminAssets/vendor/libs/jquery/jquery.js') }}"></script>
<script src="{{ asset('adminAssets/vendor/libs/popper/popper.js') }}"></script>
<script src="{{ asset('adminAssets/vendor/js/bootstrap.js') }}"></script>
<script src="{{ asset('adminAssets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js') }}"></script>

<script src="{{ asset('adminAssets/vendor/js/menu.js') }}"></script>
<!-- endbuild -->

<!-- Vendors JS -->

<!-- Main JS -->
<script src="{{ asset('adminAssets/js/main.js') }}"></script>