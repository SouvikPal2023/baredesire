<!-- [ breadcrumb ] start -->

<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home/</span> @yield('title')</h4>
<!-- [ breadcrumb ] end -->