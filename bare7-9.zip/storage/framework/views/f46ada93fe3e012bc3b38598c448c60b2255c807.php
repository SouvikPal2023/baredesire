<?php $__env->startSection('title', 'Product Category List'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">

  

  <div>
    <a href="<?php echo e(route('product-category.create')); ?>" class="btn btn-primary font-weight-bold mb-3">+ Add New Category</a>
  </div>

  <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h3 class="card-title">Product Categories</h3>
          <hr>

          <div class="table-responsive">
            <table class="table table-striped FAQ_LIST <?php echo count($categories)?'dataTable':'';?>">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Sub Parent Category</th>
                  <th>Parent Category</th>
                  <th>Category Level</th>
                  <th>Status</th>
                  <th>Created On</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr data-index="<?php echo e($category->id); ?>" >
                       

                      <td>
                        <?php echo e($category->name); ?>

                      </td>
                      <td>
                        <?php echo e($category->parent->name??'--'); ?>

                      </td>
                      <td>
                        <?php echo e($category->parent->parent->name ??'--'); ?>

                      </td>

                      <td>
                                  
                                  <?php if($category->level==0): ?>
                                       <?php echo e("Main Category"); ?>

                                       <?php elseif($category->level==1): ?>
                                       <?php echo e("Sub Category"); ?>

                                       <?php else: ?> <?php echo e("Sub SubCategory"); ?>

                                       <?php endif; ?>
                                </td>


                                <td>
                         <div class="dropdown action-label">
                          <a class="btn <?php if(isset($category->status) && ($category->status=='1')): ?> btn-primary <?php else: ?> btn-danger <?php endif; ?>  dropdown-toggle btn-sm text-white" data-bs-toggle="dropdown" aria-expanded="false">

                            <?=(isset($category->status) && $category->status=='1')?'<i class="fa fa-dot-circle-o text-success"></i> Active':'<i class="fa fa-dot-circle-o text-danger"></i> Inactive';?>

                            <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu">
                              <form action="<?php echo e(route('category.status', $category->id)); ?>"
                                  method="POST"
                                  >
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('PUT'); ?>
                                   <button type="submit"
                                        class="dropdown-item status-btn btn-sm"
                                        style="cursor: pointer;">

                                    <?php echo ($category->status=='1')? "<i class='fa fa-dot-circle-o text-danger'></i> Inactive":"<i class='fa fa-dot-circle-o text-success'></i> Active"; ?>

                                  </button>
                              </form>
                            </div>
                        </div>
                      </td>

                                <td>
                                      <?php echo e(\Carbon\Carbon::parse($category->created_at)->format('d/m/Y')); ?>

                                  </td>


                      <td>
                        <a href="<?php echo e(route('product-category.edit', $category)); ?>" class="btn btn-info btn-sm">
                          <i class='bx bx-edit-alt' ></i> Edit
                        </a>

                        <div class="d-inline-block">
                           <form action="<?php echo e(route('product-category.destroy', $category->id)); ?>"
                              method="POST"
                              >
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                               <button type="submit"
                                    class="btn btn-danger btn-sm Delete"
                                    style="cursor: pointer;">

                                <i class='bx bxs-trash'></i> Delete
                              </button>
                          </form>
                          </div>
                      </td>
                    </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <td colspan="4" class="text-center">Nothing is Listed Yet</td>
                <?php endif; ?>

              </tbody>
            </table>

         
          </div>
        </div>
      </div>
    </div>
  </div>


</div>



<?php echo $__env->make('admin.common.deleteConfirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/product-category/list.blade.php ENDPATH**/ ?>