
<div class="mb-3">
  <div class="row">
    <div class="col-md-7">
      <label for="ProfileImage" class="form-label">
        Image 
      </label>
      <input type="file" name="image" accept="image/*" id="ProfileImage" onchange="showSelectedImagesss(this)" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
    </div>

    <div class="col-md-5">
        <img src="<?php echo e(isset($section->image) ? config("app.url").Storage::url($section->image) : asset('adminAssets/img/default-image.png')); ?>"
         id="SelectedImgsss"
         class="w-px-100 h-px-100 rounded-circle"
         title="section Image"
         alt="section_image">
    </div>
  </div>
</div>





<div class="mb-3">
  <label class="form-label" for="Name">Heading <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="heading" 
           class="form-control <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="heading" 
           placeholder="Enter Heading" 
           value="<?php echo e(old('heading', isset($section->heading) ? $section->heading:'')); ?>" 
            />
  </div>
</div>

<div class="mb-3">
  <label class="form-label" for="Name">Description <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="desc" 
           class="form-control <?php $__errorArgs = ['desc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="desc" 
           placeholder="Enter Sub Heading" 
           value="<?php echo e(old('desc', isset($section->desc) ? $section->desc:'')); ?>" 
            />
  </div>
</div>







<div class="mb-3">
  <label class="form-label" for="Name">Button Text </label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="btn_text" 
           class="form-control <?php $__errorArgs = ['btn_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="btn_text" 
           placeholder="Enter Button 1 Text" 
           value="<?php echo e(old('btn_text', isset($section->btn_text) ? $section->btn_text:'')); ?>" 
            />
  </div>
</div>

<div class="mb-3">
  <label class="form-label" for="Name">Button URL </label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="btn_url" 
           class="form-control <?php $__errorArgs = ['btn_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="btn_url" 
           placeholder="Enter Button 1 URL" 
           value="<?php echo e(old('btn_url', isset($section->btn_url) ? $section->btn_url:'')); ?>" 
            />
  </div>
</div>






<button type="submit" class="btn btn-primary"><?php echo e(isset($section) ? 'Update' : 'Create'); ?></button>
<a class="btn btn-dark" href="<?php echo e(route('homeSection5.index')); ?>">Cancel</a>




<script>
  function showSelectedImages(input) {
  if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
          $('#SelectedImgs').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
  }
}

function showSelectedImagesss(input) {
  if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
          $('#SelectedImgsss').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
  }
}

function showSelectedImagess(input) {
  if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
          $('#SelectedImgss').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
  }
}
</script>

<?php echo $__env->make('admin.common.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php /**PATH /home/baredesire/public_html/resources/views/admin/homeSection/section5/form.blade.php ENDPATH**/ ?>