<!-- Core JS -->
<!-- build:js assets/vendor/js/core.js -->
<script src="<?php echo e(asset('adminAssets/vendor/libs/jquery/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('adminAssets/vendor/libs/popper/popper.js')); ?>"></script>
<script src="<?php echo e(asset('adminAssets/vendor/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('adminAssets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>

<script src="<?php echo e(asset('adminAssets/vendor/js/menu.js')); ?>"></script>
<!-- endbuild -->

<!-- Vendors JS -->

<!-- Main JS -->
<script src="<?php echo e(asset('adminAssets/js/main.js')); ?>"></script><?php /**PATH /home/baredesire/public_html/resources/views/admin/layout/partials/login/scripts.blade.php ENDPATH**/ ?>