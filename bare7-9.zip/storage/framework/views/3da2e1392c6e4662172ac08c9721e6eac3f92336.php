<?php echo $__env->make('frontend.partials.headerCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <!-- inner-banner -->
 <section class="section breadcrumb-wrapper">
        <div class="shell">
          <h2>Contact Us</h2>
        </div>
      </section>
      <!-- inner-banner end -->

      <section class="service-wrap">
        <div class="container">
          <div class="row">
  <div class="col-md-12">
        <div class="service-box">
                <div class="inner_page_wrap about_inner_pg_wrap inner">

    <div class="container">
      <div class="row">
        <div class="col-md-12 m-0 p-0">
          <div class="contact-item">
            <div class="address-content">
              <h5><?php echo e($setting->contact_title); ?> </h5>
              <p><?php echo e($setting->address); ?></p>
            </div>
            <span class="icon"><i class="fa fa-rocket"></i></span>
          </div>
          <div class="contact-item">
            <div class="address-content">
              <h5>Call Us:</h5>
              <a href="tel:123456789"><?php echo e($setting->site_phone); ?></a>
            </div>
            <span class="icon"><i class="fa fa-volume-control-phone"></i></span>
          </div>
          <div class="contact-item">
            <div class="address-content">
              <h5>Mail Us:</h5>
              <p><a href="mailto:baredsire@gmail.com">
              <?php echo e($setting->site_email); ?></a>
            </p>
          </div>
          <span class="icon"><i class="fa fa-envelope-open-o"></i></span>
        </div>
        <!--<div class="map_section">-->
        <!-- <?php echo $setting->map_link; ?>-->
        <!--</div>-->
      </div>
        <!--<div class="col-md-12 m-0 p-0">-->
        <!--  <div class="contact-form">-->
        <!--    <div class="form-header">-->
        <!--      <h2>Send Us an Enquiry</h2>-->
        <!--    </div>-->
        <!--    <div class="form-sec" id="my_form">-->
        <!--      <form class="rd-mailform1" action="<?php echo e(route('contact')); ?>" method="POST"-->
        <!--                    enctype="multipart/form-data">-->
        <!--                    <?php echo csrf_field(); ?>-->
        <!--        <div class="row">-->
        <!--          <div class="col-md-12">-->
        <!--            <div class="form-group">-->
        <!--              <input type="text" class="form-control" placeholder="Name" name="name">-->
        <!--            </div>-->
        <!--          </div>-->
        <!--          <div class="col-md-12">-->
        <!--            <div class="form-group">-->
        <!--              <input type="text" class="form-control" placeholder="Phone No." name="phone">-->
        <!--            </div>-->
        <!--          </div>-->
        <!--          <div class="col-md-12">-->
        <!--            <div class="form-group">-->
        <!--              <input type="text" class="form-control" placeholder="Email" name="email">-->
        <!--            </div>-->
        <!--          </div>-->
        <!--          <div class="col-md-12">-->
        <!--            <div class="form-group">-->
        <!--              <input type="text" class="form-control" placeholder="Subject" name="subject">-->
        <!--            </div>-->
        <!--          </div>-->
        <!--          <div class="col-md-12">-->
        <!--            <div class="form-group">-->
        <!--              <textarea class="form-control" placeholder="Message*" name="message"></textarea>-->
        <!--            </div>-->
        <!--          </div>-->
        <!--        </div>-->
        <!--        <div class="text-center">-->
        <!--          <button class="contact_submit_btn" type="submit">Submit</button>-->
        <!--        </div>-->
        <!--      </form>-->
        <!--    </div>-->
        <!--  </div>-->
        <!--</div>-->
        
    </div>
  </div>
</div>

              </div>
  </div>
</div>
</div>
</section>

<!-- footer -->

<?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('frontend.partials.footerScripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/frontend/contents/contact.blade.php ENDPATH**/ ?>