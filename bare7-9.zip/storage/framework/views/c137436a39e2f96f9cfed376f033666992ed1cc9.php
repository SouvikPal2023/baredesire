<!DOCTYPE html>
<html lang="en">
    
<?php echo $__env->make('admin.layout.partials.main.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body>

        <div class="layout-wrapper layout-content-navbar">
            <div class="layout-container">
                <!-- Left-Sidebar -->
                    <?php echo $__env->make('admin.layout.partials.main.leftSidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- / Left-Sidebar -->

                <div class="layout-page">
                <!-- Header -->
                    <?php echo $__env->make('admin.layout.partials.main.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- /Header -->
                    <div class="content-wrapper">
                        <div class="container-xxl flex-grow-1 container-p-y">
                            <?php echo $__env->make('admin.layout.partials.main.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <!-- Page Wrapper -->
                            <?php echo $__env->yieldContent('content'); ?>
                        <!-- /Page Wrapper -->
                        </div>
                    <!-- Footer -->
                        <?php echo $__env->make('admin.layout.partials.main.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- /Footer -->
                    </div>
                </div>
            </div>
        </div>

       

        <?php echo $__env->make('admin.common.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('admin.layout.partials.main.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html><?php /**PATH /home/baredesire/public_html/resources/views/admin/layout/adminMasterLayout.blade.php ENDPATH**/ ?>