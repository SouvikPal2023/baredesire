<link rel="stylesheet" href="<?php echo e(asset('vendor/iziToast/iziToast.min.css')); ?>">
<script src="<?php echo e(asset('vendor/iziToast/iziToast.min.js')); ?>"></script>

<?php if(session()->has('notify')): ?>
    <?php $__currentLoopData = session('notify'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <script> 
            "use strict";
            iziToast.<?php echo e($msg[0]); ?>({message:"<?php echo e(__($msg[1])); ?>", position: "topCenter"}); 
        </script>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>



<?php if(session('status')): ?>
    <script>
        "use strict";
       
        iziToast.success({
            message: '<?php echo e(session('status')); ?>',
            position: "topRight"
        });
     
    </script>
<?php endif; ?>



<?php if($errors->any()): ?>
    <?php
        $collection = collect($errors->all());
        $errors = $collection->unique();
    ?>

    <script>
        "use strict";
        <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        iziToast.error({
            message: '<?php echo e(__($error)); ?>',
            position: "topRight"
        });
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>

<?php endif; ?>
<script>
    "use strict";
    function notify(status,message) {
        iziToast[status]({
            message: message,
            position: "topRight"
        });
    }
</script><?php /**PATH /home/baredesire/public_html/resources/views/admin/common/notify.blade.php ENDPATH**/ ?>