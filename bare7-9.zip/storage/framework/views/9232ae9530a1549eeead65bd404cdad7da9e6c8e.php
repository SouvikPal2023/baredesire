
<div class="mb-3">
  <label class="form-label" for="Name">Heading <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="heading" 
           class="form-control <?php $__errorArgs = ['heading'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="heading" 
           placeholder="Enter Heading" 
           value="<?php echo e(old('heading', isset($section->heading) ? $section->heading:'')); ?>" 
            />
  </div>
</div>






<div class="mb-3">
  <div class="row">
    <div class="col-md-7">
      <label for="ProfileImage" class="form-label">
       Section Image 1
      </label>
      <input type="file" name="image1" accept="image/*" id="ProfileImage" onchange="showSelectedImagesss(this)" class="form-control <?php $__errorArgs = ['image1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
    </div>

    <div class="col-md-5">
        <img src="<?php echo e(isset($section->image1) ? config("app.url").Storage::url($section->image1) : asset('adminAssets/img/default-image.png')); ?>"
         id="SelectedImgsss"
         class="w-px-100 h-px-100 rounded-circle"
         title="section Image"
         alt="section_image">
    </div>
  </div>
</div>

<div class="mb-3">
  <label class="form-label" for="Name">Image 1 Text <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="image1_text" 
           class="form-control <?php $__errorArgs = ['image1_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="image1_text" 
           placeholder="Enter Image1 Text" 
           value="<?php echo e(old('image1_text', isset($section->image1_text) ? $section->image1_text:'')); ?>" 
            />
  </div>
</div>
<div class="mb-3">
  <label class="form-label" for="Name">Button 1 Text </label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="btn1_text" 
           class="form-control <?php $__errorArgs = ['btn1_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="btn1_text" 
           placeholder="Enter Button 1 Text" 
           value="<?php echo e(old('btn1_text', isset($section->btn1_text) ? $section->btn1_text:'')); ?>" 
            />
  </div>
</div>

<div class="mb-3">
  <label class="form-label" for="Name">Button 1 URL </label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="btn1_url" 
           class="form-control <?php $__errorArgs = ['btn1_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="btn1_url" 
           placeholder="Enter Button 1 URL" 
           value="<?php echo e(old('btn1_url', isset($section->btn1_url) ? $section->btn1_url:'')); ?>" 
            />
  </div>
</div>

<div class="mb-3">
  <div class="row">
    <div class="col-md-7">
      <label for="ProfileImage" class="form-label">
       Section Image 2
      </label>
      <input type="file" name="image2" accept="image/*" id="ProfileImage" onchange="showSelectedImages(this)" class="form-control <?php $__errorArgs = ['image2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
    </div>

    <div class="col-md-5">
        <img src="<?php echo e(isset($section->image2) ? config("app.url").Storage::url($section->image2) : asset('adminAssets/img/default-image.png')); ?>"
         id="SelectedImgs"
         class="w-px-100 h-px-100 rounded-circle"
         title="section Image"
         alt="section_image">
    </div>
  </div>
</div>
<div class="mb-3">
  <label class="form-label" for="Name">Image 2 Text <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="image2_text" 
           class="form-control <?php $__errorArgs = ['image2_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="image2_text" 
           placeholder="Enter Image2 Text" 
           value="<?php echo e(old('image2_text', isset($section->image2_text) ? $section->image2_text:'')); ?>" 
            />
  </div>
</div>







<div class="mb-3">
  <label class="form-label" for="Name">Button 2 Text </label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="btn2_text" 
           class="form-control <?php $__errorArgs = ['btn2_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="btn2_text" 
           placeholder="Enter Button 2 Text" 
           value="<?php echo e(old('btn2_text', isset($section->btn2_text) ? $section->btn2_text:'')); ?>" 
            />
  </div>
</div>

<div class="mb-3">
  <label class="form-label" for="Name">Button 2 URL </label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="btn2_url" 
           class="form-control <?php $__errorArgs = ['btn2_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="btn2_url" 
           placeholder="Enter Button 1 URL" 
           value="<?php echo e(old('btn2_url', isset($section->btn2_url) ? $section->btn2_url:'')); ?>" 
            />
  </div>
</div>





<button type="submit" class="btn btn-primary"><?php echo e(isset($section) ? 'Update' : 'Create'); ?></button>
<a class="btn btn-dark" href="<?php echo e(route('homeSection3.index')); ?>">Cancel</a>




<script>
  function showSelectedImages(input) {
  if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
          $('#SelectedImgs').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
  }
}

function showSelectedImagesss(input) {
  if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
          $('#SelectedImgsss').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
  }
}

function showSelectedImagess(input) {
  if (input.files && input.files[0]) {
      var reader = new FileReader();
      reader.onload = function (e) {
          $('#SelectedImgss').attr('src', e.target.result);
      }
      reader.readAsDataURL(input.files[0]);
  }
}
</script>

<?php echo $__env->make('admin.common.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php /**PATH /home/baredesire/public_html/resources/views/admin/homeSection/section3/form.blade.php ENDPATH**/ ?>