

<?php $__env->startSection('title', 'Change Password'); ?>

<?php $__env->startSection('content'); ?>



<div class="auth-content">
  <div class="card">
    <div class="row align-items-center text-center">
      <div class="col-md-12">
        <div class="card-body">
          <img src="<?php echo e(isset($setting->site_logo) ? config("app.url").Storage::url($setting->site_logo) : asset('adminAssets/images/logo-dark.png')); ?>" alt="logo" class="img-fluid mb-4 hei-110"/>
          <h4><?php echo e(isset($setting->site_name) ? $setting->site_name : env('APP_NAME')); ?> Admin!</h4>

          <h6 class="font-weight-light">Reset Password</h6>

          <form class="pt-3" action="<?php echo e(route('reset.password.submit')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="token" value="<?php echo e($token); ?>">

            <div class="form-group mb-3">
              <label class="floating-label" for="Email">Email address</label>
              <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Email" name="email" value="<?php echo e($email ?? old('email')); ?>" placeholder="Email" required autocomplete="email" autofocus>
              
            </div>

            <div class="form-group mb-4">
              <label class="floating-label" for="Password">Password</label>
               <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Password" name="password" required=""> 
 
            </div>

            <div class="form-group mb-4">
              <label class="floating-label" for="PasswordConfirm">Confirm Password</label>
               <input type="password" class="form-control <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="PasswordConfirm" name="password_confirmation" required=""> 
 
            </div>
            
            <button class="btn btn-block btn-primary mb-4" type="submit"> Reset Password</button>

          </form>
          <p class="my-4 text-muted">
            Copyright &copy; <?php echo e(date('Y')); ?>  All rights reserved.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.loginLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/auth/forgetPasswordLink.blade.php ENDPATH**/ ?>