

<div class="mb-3">
  <div class="row">
    <div class="col-md-7">
      <label for="SiteLogo" class="form-label">Site Logo</label>
      <input type="file" 
             name="site_logo" 
             accept="image/*" 
             id="SiteLogo" 
             onchange="showSiteLogo(this)" 
             class="form-control <?php $__errorArgs = ['site_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
    </div>

    <div class="col-md-5">
      <img src="<?php echo e(isset($siteSetting->site_logo) ? config("app.url").Storage::url($siteSetting->site_logo) : asset('adminAssets/img/default-image.png')); ?>"
         id="SiteLogoImg"
         class="w-px-200 rounded h-px-50"
         title="Site Logo"
         alt="site_logo">
    </div>
  </div>
</div>


<div class="mb-3">
  <div class="row">
    <div class="col-md-7">
      <label for="LightLogo" class="form-label">Light Logo</label>
      <input type="file" 
             name="light_logo" 
             accept="image/*" 
             id="LightLogo" 
             onchange="showLightLogo(this)" 
             class="form-control <?php $__errorArgs = ['light_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
    </div>

    <div class="col-md-5">
        <img src="<?php echo e(isset($siteSetting->light_logo) ? config("app.url").Storage::url($siteSetting->light_logo) : asset('adminAssets/img/default-image.png')); ?>"
         id="LightLogoImg"
         class="w-px-200 rounded h-px-50 bg-dark"
         title="Light Logo"
         alt="light_logo">
    </div>
  </div>
</div>


<div class="mb-3">
  <div class="row">
    <div class="col-md-7">
      <label for="Favicon" class="form-label">Favicon</label>
      <input type="file" 
             name="favicon" 
             accept="image/*" 
             id="Favicon" 
             onchange="showFavicon(this)" 
             class="form-control <?php $__errorArgs = ['favicon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
    </div>

    <div class="col-md-5">
        <img src="<?php echo e(isset($siteSetting->favicon) ? config("app.url").Storage::url($siteSetting->favicon) : asset('adminAssets/img/default-image.png')); ?>"
         id="FaviconImg"
         class="w-px-100 h-px-100 rounded-circle bg-dark"
         title="Favicon"
         alt="favicon">
    </div>
  </div>
</div>




<div class="mb-3">
  <label class="form-label" for="SiteName">Site Name<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bxs-book-content' ></i> 
    </span>
   <input type="text" 
           name="site_name" 
           class="form-control <?php $__errorArgs = ['site_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="SiteName" 
           placeholder="Site Name" 
           value="<?php echo e(old('site_name', isset($siteSetting->site_name) ? $siteSetting->site_name:'')); ?>" 
            />
  </div>
</div>







<div class="mb-3">
  <label class="form-label" for="MetaTitle">Meta Title <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bxs-book-content' ></i> 
    </span>

   <input type="text" 
           name="meta_title" 
           class="form-control <?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="MetaTitle" 
           placeholder="Meta Title" 
           value="<?php echo e(old('meta_title', isset($siteSetting->meta_title) ? $siteSetting->meta_title:'')); ?>" 
            />
  </div>
</div>


<div class="mb-3">
  <label class="form-label" for="MetaKeyword">Meta Keyword</label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bxs-book-content' ></i> 
    </span>
    
    <input type="text" 
           name="meta_keyword" 
           class="form-control <?php $__errorArgs = ['meta_keyword'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="MetaKeyword" 
           placeholder="Meta Keyword" 
           value="<?php echo e(old('meta_keyword', isset($siteSetting->meta_keyword) ? $siteSetting->meta_keyword:'')); ?>" 
            />
  </div>
</div>



<div class="mb-3">
  <label class="form-label" for="MetaDescription">Meta Description</label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bxs-book-content' ></i> 
    </span>
    
   <textarea class="form-control <?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
              rows="4" 
              name="meta_description" 
              id="MetaDescription"><?php echo e(old('meta_description', isset($siteSetting->meta_description) ? $siteSetting->meta_description:'')); ?></textarea>
  </div>
</div>













<div class="mb-3">
  <label class="form-label" for="CopyrightText">Copyright Text <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bx-copyright' ></i> 
    </span>

  <input type="text" 
           name="copyright_text" 
           class="form-control <?php $__errorArgs = ['copyright_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="CopyrightText" 
           placeholder="Copyright Text" 
           value="<?php echo e(old('copyright_text', isset($siteSetting->copyright_text) ? $siteSetting->copyright_text:'')); ?>" 
            />
  </div>
</div>


<div class="mb-3">
  <label class="form-label" for="FooterText">Footer Text</label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bxs-book-content' ></i> 
    </span>

    <input type="text" 
           name="footer_text" 
           class="form-control <?php $__errorArgs = ['footer_text'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="FooterText" 
           placeholder="Footer Text" 
           value="<?php echo e(old('footer_text', isset($siteSetting->footer_text) ? $siteSetting->footer_text:'')); ?>"/>
  </div>
</div>




















<div class="mb-3 mt-sm-5">
  <hr style="color: #696cff;">

  <label class="form-label" for="ContactTitle">Contact Title<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bxs-book-content' ></i> 
    </span>
   <input type="text" 
           name="contact_title" 
           class="form-control <?php $__errorArgs = ['contact_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="ContactTitle" 
           placeholder="Contact Title" 
           value="<?php echo e(old('contact_title', isset($siteSetting->contact_title) ? $siteSetting->contact_title:'')); ?>" 
            />
  </div>
</div>


<div class="mb-3">
  <label class="form-label" for="SiteEmail">Contact Email <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">
    <span class="input-group-text"><i class="bx bx-envelope"></i></span>
    <input type="email" 
           name="site_email" 
           class="form-control <?php $__errorArgs = ['site_email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="SiteEmail" 
           placeholder="Contact Email" 
           value="<?php echo e(old('site_email', isset($siteSetting->site_email) ? $siteSetting->site_email:'')); ?>" 
            />
  </div>
</div>


<div class="mb-3">
  <label class="form-label" for="SitePhone">Contact Phone</label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bx-phone-call' ></i>
    </span>

    <input type="tel" 
           name="site_phone" 
           class="form-control <?php $__errorArgs = ['site_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="SitePhone" 
           placeholder="Contact Phone" 
           value="<?php echo e(old('site_phone', isset($siteSetting->site_phone) ? $siteSetting->site_phone:'')); ?>" />
  </div>
</div>


<div class="mb-3">
  <label class="form-label" for="ContactAddress">Contact Address</label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bxs-book-content' ></i> 
    </span>
    
   <textarea class="form-control <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
              rows="4" 
              name="address" 
              id="ContactAddress"><?php echo e(old('address', isset($siteSetting->address) ? $siteSetting->address:'')); ?></textarea>
  </div>
</div>


<div class="mb-3">
  <label class="form-label" for="MapLink">Map Link</label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bxs-book-content' ></i> 
    </span>
    
   <textarea class="form-control <?php $__errorArgs = ['map_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
              rows="4" 
              name="map_link" 
              id="MapLink"><?php echo e(old('map_link', isset($siteSetting->map_link) ? $siteSetting->map_link:'')); ?></textarea>
  </div>
</div>



<div class="mb-3">
  <div class="row">
    <div class="col-md-7">
      <label for="PartnerImage1" class="form-label">WhatsApp Logo</label>
      <input type="file" 
             name="whatsapp_logo" 
             accept="image/*" 
             id="PartnerImage1" 
             onchange="showPartnerImage1(this)" 
             class="form-control <?php $__errorArgs = ['whatsapp_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
    </div>

    <div class="col-md-5">
        <img src="<?php echo e(isset($siteSetting->whatsapp_logo) ? config("app.url").Storage::url($siteSetting->whatsapp_logo) : asset('adminAssets/img/default-image.png')); ?>"
         id="PartnerImg1"
         class="w-px-100 h-px-100 rounded-circle bg-dark"
         title="PartnerImage1"
         alt="whatsapp_logo">
    </div>
  </div>
</div>

<div class="mb-3">
  <label class="form-label" for="SitePhone">WhatsApp No</label>
  <div class="input-group input-group-merge">
    <span class="input-group-text">
      <i class='bx bx-phone-call' ></i>
    </span>

    <input type="tel" 
           name="site_whatsapp" 
           class="form-control <?php $__errorArgs = ['site_whatsapp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="SitePhone" 
           placeholder="Contact Phone" 
           value="<?php echo e(old('site_whatsapp', isset($siteSetting->site_whatsapp) ? $siteSetting->site_whatsapp:'')); ?>" />
  </div>
</div>


<div class="mb-3">
  <div class="row">
    <div class="col-md-7">
      <label for="PartnerImage1" class="form-label">WhatsApp Logo</label>
      <input type="file" 
             name="size_chart_image" 
             accept="image/*" 
             id="PartnerImage2" 
             onchange="showPartnerImage2(this)" 
             class="form-control <?php $__errorArgs = ['size_chart_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
    </div>

    <div class="col-md-5">
        <img src="<?php echo e(isset($siteSetting->size_chart_image) ? config("app.url").Storage::url($siteSetting->size_chart_image) : asset('adminAssets/img/default-image.png')); ?>"
         id="PartnerImg2"
         class="w-px-100 h-px-100 rounded-circle bg-dark"
         title="PartnerImage2"
         alt="size_chart_image">
    </div>
  </div>
</div>








<button type="submit" class="btn btn-primary">Update</button>
<a class="btn btn-danger" href="<?php echo e(route('siteSetting.index')); ?>">Cancel</a>










<script>
   function showSiteLogo(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          
          reader.onload = function (e) {
              $('#SiteLogoImg').attr('src', e.target.result);
          }
          reader.readAsDataURL(input.files[0]);
      }
    }


  function showLightLogo(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          
          reader.onload = function (e) {
              $('#LightLogoImg').attr('src', e.target.result);
          }
          reader.readAsDataURL(input.files[0]);
      }
    }


  function showFavicon(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          
          reader.onload = function (e) {
              $('#FaviconImg').attr('src', e.target.result);
          }
          reader.readAsDataURL(input.files[0]);
      }
    }


  function showOGImage(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          
          reader.onload = function (e) {
              $('#OGImg').attr('src', e.target.result);
          }
          reader.readAsDataURL(input.files[0]);
      }
    }



  function showPartnerImage1(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          
          reader.onload = function (e) {
              $('#PartnerImg1').attr('src', e.target.result);
          }
          reader.readAsDataURL(input.files[0]);
      }
    }


    function showPartnerImage2(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          
          reader.onload = function (e) {
              $('#PartnerImg2').attr('src', e.target.result);
          }
          reader.readAsDataURL(input.files[0]);
      }
    }

</script>

<?php /**PATH /home/baredesire/public_html/resources/views/admin/siteSetting/form.blade.php ENDPATH**/ ?>