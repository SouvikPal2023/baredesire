<?php echo $__env->make('frontend.partials.headerCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- inner-banner -->
<section class="section breadcrumb-wrapper">
    <div class="shell">
        <h2>Wish List</h2>
    </div>
</section>
<!-- inner-banner end -->

<section class="service-wrap">
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="service-box">
                    <form>
                        <div class="col-md-6">
                            <!--<div class="form-group d-flex order-search">-->
                            <!--    <input type="text" class="form-control" id="exampleFormControlInput1"-->
                            <!--        placeholder="Search Order">-->
                            <!--    <a href="#"><i class="fa fa-search" aria-hidden="true"></i></a>-->
                            <!--</div>-->
                        </div>

                    </form>

                    <div class="service-box">
                        <div class="wishlist">
                            <div class="wishlist-wrap">
                                <?php if($wishlists->isEmpty()): ?>



                                <p><?php echo e('Wishlist is empty!!'); ?></p>
                                <?php else: ?>
                                <?php
                                $i=1;
                                 $j=1;
                                ?>
                                <?php $__currentLoopData = $wishlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php

                                $h=1;
                                ?>
                                <?php
                                $product=App\Models\Product::with(['product_images' => function ($query) {
                                $query->take(2);
                                }])->find($list->product_id);


                                ?>
                                <div class="wishlist-wrap-box">
                                    <?php $__currentLoopData = $product->product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="wishlist-image<?php echo e($h++); ?>"><img
                                            src="<?php echo e(isset($image->image) ? config("app.url").Storage::url($image->image) :asset('assets/images/fun2.jpg')); ?>"
                                            alt=""></div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="product-details">
                                        <p><?php echo e(Str::limit($product->name, 50)); ?></p>
                                        <p class="price-tag">Rs <?php echo e($product->original_price); ?></p>
                                    </div>
                                    <div class="product-button">
                                        <a href="#" data-target="#size-modal<?php echo e($i); ?>" data-toggle="modal">Add to
                                            Cart</a>
                                        <form action="<?php echo e(route('removeItem',$list->id)); ?> " method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <p><button type="submit" class="Delete">Remove</button></p></form>
                                    </div>
                                    <!-- Modal -->
                                    <div class="modal fade size-chart" id="size-modal<?php echo e($i); ?>" tabindex="-1"
                                        aria-hidden="true">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="size-modal<?php echo e($i); ?>">Size Chart</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="<?php echo e(route('wishToCart')); ?>" method="POST"
                                                        enctype="multipart/form-data">

                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="id"  value="<?php echo e($product->id); ?>" />
                                                        <input type="hidden" name="cart"  value="<?php echo e($list->id); ?>" />
                                                        <input type="hidden" name="quantity" value="1" />
                                                        <ul class="free-selected size_mar listNone Sizeslist normal radio-button"
                                                            id="selectSize2">
                                                           
                                                            <?php $__currentLoopData = $product->product_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <input type="radio" id="radio<?php echo e($j); ?>" name="size"
                                                            value="<?php echo e($size->size); ?>">
                                                            <label for="radio<?php echo e($j); ?>"><?php echo e($size->size); ?></label>
                                                            
                                                            <?php
                                                            $j++;
                                                            ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </ul>
                                                    
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" class="btn btn-primary">Go To Cart</button>
                                                    <!-- <button type="button" class="btn btn-primary">Submit</button> -->
                                                </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php
                                $i++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script>
$('.Delete').on('click', function(e) {

    e.preventDefault();
    //alert(0);
    var single = $(this);

    iziToast.question({
        overlay: true,
        toastOnce: true,
        id: 'question',
        title: 'Hey',
        message: 'Are you sure you want to delete?',
        position: 'center',
        buttons: [
            ['<button><b>YES</b></button>', function(instance, toast) {

                instance.hide({
                    transitionOut: 'fadeOut'
                }, toast);

                single.closest("form").submit();


            }, true],
            ['<button>NO</button>', function(instance, toast) {

                instance.hide({
                    transitionOut: 'fadeOut'
                }, toast);

            }]
        ]
    });

});
</script>
<?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('frontend.partials.footerScripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/frontend/contents/wishlist.blade.php ENDPATH**/ ?>