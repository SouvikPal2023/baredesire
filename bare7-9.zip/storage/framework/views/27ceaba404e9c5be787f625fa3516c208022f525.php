

<?php $__env->startSection('title', 'Product Sizes'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  


  <div>
    <a href="<?php echo e(route('product-size.create')); ?>" class="btn btn-primary font-weight-bold mb-3">
      + Add New Size
    </a>
  </div>

  <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Product Size List</h4>
          <hr>
        
          <div class="table-responsive">
            <table class="table table-striped FAQ_LIST <?php echo count($sizes)?'dataTable':'';?>">
              <thead>
                <tr>
                 
                  <th>Size</th>
                  <th>Type</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                <?php if($sizes->count() > 0 ): ?>
                  <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      
                      <td>
                          <?php echo e($size->size ?? '--'); ?>

                      </td>
                      <td>
                          <?php echo e($size->type ?? '--'); ?>

                      </td>
                      
                     
                      <td>
                         <a href="<?php echo e(route('product-size.edit', $size)); ?>" class="btn btn-info btn-sm">
                          <i class='bx bx-edit-alt' ></i> Edit
                         </a>

                        <div class="d-inline-block">
                           <form action="<?php echo e(route('product-size.destroy', $size->id)); ?>" 
                              method="POST" 
                              >
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                               <button type="submit" 
                                    class="btn btn-danger btn-sm Delete" 
                                    style="cursor: pointer;">
                                
                                <i class='bx bxs-trash'></i> Delete
                              </button>
                          </form>
                          </div>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <td colspan="3" class="text-center">No Data Listed Yet</td>
                <?php endif; ?>
               
              </tbody>
            </table>

           
          </div>
        </div>
      </div>
    </div>
  </div>

</div>


<?php echo $__env->make('admin.common.deleteConfirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/product-size/list.blade.php ENDPATH**/ ?>