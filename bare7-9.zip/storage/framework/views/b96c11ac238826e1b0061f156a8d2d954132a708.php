<!DOCTYPE html>
<html lang="en" class="light-style customizer-hide">
    
    <?php echo $__env->make('admin.layout.partials.login.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <body>
        <div class="container-xxl">
            <div class="authentication-wrapper authentication-basic container-p-y">
                <div class="authentication-inner">
                    <!-- Page Wrapper -->
                    <?php echo $__env->yieldContent('content'); ?>
                    <!-- /Page Wrapper -->
                </div>
            </div>
        </div>
        <!-- /Main Wrapper -->
        
        <?php echo $__env->make('admin.common.notify', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('admin.layout.partials.login.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html><?php /**PATH /home/baredesire/public_html/resources/views/admin/layout/loginLayout.blade.php ENDPATH**/ ?>