

<?php $__env->startSection('title', 'Add Social Link'); ?>

<?php $__env->startSection('content'); ?>





<div class="row">
  <div class="col-xl-12">
    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Add a Social Link</h5>
      </div>
      <div class="card-body">
         <form class="forms-sample" 
               action="<?php echo e(route('socialLink.store')); ?>"
               method="POST" 
               autocomplete="off"
               enctype="multipart/form-data">

          <?php echo csrf_field(); ?>
          <?php echo $__env->make('admin.socialLink.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </form>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/socialLink/create.blade.php ENDPATH**/ ?>