<!-- [ breadcrumb ] start -->

<h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Home/</span> <?php echo $__env->yieldContent('title'); ?></h4>
<!-- [ breadcrumb ] end --><?php /**PATH /home/baredesire/public_html/resources/views/admin/layout/partials/main/breadcrumb.blade.php ENDPATH**/ ?>