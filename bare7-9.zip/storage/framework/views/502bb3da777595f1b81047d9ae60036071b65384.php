

<?php $__env->startSection('title', 'Site Settings List'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">

  <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Site Settings List</h4>
          <hr>
        
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Site Logo</th>
                  <th>Light Logo</th>
                  <th>Favicon</th>
                  <th>Site Name</th>
                  <th>Meta Title</th>
                  <th>Meta Keyword</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                <?php if($siteSettings->count() > 0 ): ?>
                  <?php $__currentLoopData = $siteSettings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siteSetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>

                      <td class="py-1">
                        <img src="<?php echo e((isset($siteSetting->site_logo) AND Storage::disk('local')->exists($siteSetting->site_logo)) ? config("app.url").Storage::url($siteSetting->site_logo) : asset('adminAssets/img/default-image.png')); ?>" alt="site_logo" class="w-px-100 rounded" />
                      </td>

                      <td class="py-1">
                        <img src="<?php echo e((isset($siteSetting->light_logo) AND Storage::disk('local')->exists($siteSetting->light_logo)) ? config("app.url").Storage::url($siteSetting->light_logo) : asset('adminAssets/img/default-image.png')); ?>" alt="site_light_logo" class="w-px-100 rounded bg-dark"/>
                      </td>
                      
                      <td class="py-1">
                        <img src="<?php echo e((isset($siteSetting->favicon) AND Storage::disk('local')->exists($siteSetting->favicon)) ? config("app.url").Storage::url($siteSetting->favicon) : asset('adminAssets/img/default-image.png')); ?>" alt="site_favicon" class="w-px-50 rounded-circle bg-dark"/>
                      </td>
                      <td>
                          <?php echo e($siteSetting->site_name); ?>

                      </td>
                      <td>
                          <?php echo e($siteSetting->meta_title); ?>

                      </td>
                      <td>
                        <?php echo e($siteSetting->meta_keyword); ?>

                      </td>
                      <td>
                         <a href="<?php echo e(route('siteSetting.edit', $siteSetting)); ?>" class="btn btn-primary">
                           <i class='bx bx-edit-alt' ></i> Edit
                         </a>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <td colspan="7" class="text-center">Site Settings not available</td>
                <?php endif; ?>
               
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/siteSetting/list.blade.php ENDPATH**/ ?>