<div class="mb-3">
  <label class="form-label" for="FaqQuestion">Product Category Name<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

   <input type="text"
           name="name"
           class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="ProductCatName"
           placeholder="Enter Name"
           value="<?php echo e(old('name', isset($category->name) ? $category->name:'')); ?>"
           required />
  </div>
</div>

<div class="mb-3">
    <label class="form-label" for="FaqQuestion">Category Description</label>
    <div class="input-group input-group-merge">

      <textarea rows="12" class="form-control no-resize Editor" name="description" placeholder="Description"><?php echo e(old('description') ?? ($category->description ?? '')); ?></textarea>
    </div>
  </div>

<div class="mb-3">
    <div class="row">
      <div class="col-md-7">
        <label for="ProfileImage" class="form-label">
          Banner Image
        </label>
        <input type="file" name="banner_image" accept="image/*" id="ProfileImage" onchange="showSelectedImage(this)" class="form-control <?php $__errorArgs = ['banner_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
      </div>

      <div class="col-md-5">
          <img src="<?php echo e(isset($category->banner_image) ? config("app.url").Storage::url($category->banner_image) : asset('adminAssets/img/default-image.png')); ?>"
           id="SelectedImg"
           class="w-px-100 h-px-100 rounded-circle"
           title="Banner Image"
           alt="Banner_image">
      </div>
    </div>
  </div>

  <div class="mb-3">
  <label class="form-label" for="level">Product Category Level<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

  <select class="form-control show-tick" name="level" id="menu1">
               <option value="" Disabled selected> Select Type </option>
            
               <option value="0" <?php echo e((!empty($category->level) && $category->level == 0) || old('level')==0 ? 'selected':''); ?>> Main Category </option>
               <option value="1" <?php echo e((!empty($category->level) && $category->level == 1)|| old('level')==1 ? 'selected':''); ?>> Filter Category</option>
               <option value="2" <?php echo e((!empty($category->level) && $category->level == 2) || old('level')==2 ? 'selected':''); ?>> Sub-Category </option>
            </select>
  </div>
</div>

<div class="mb-3" id="Menu2Container" style="<?php if((isset($category->level) && ($category->level == 0 )) ): ?><?php echo e('display:none;'); ?> <?php else: ?> <?php echo e('display:block;'); ?> <?php endif; ?>">
  <label class="form-label" for="level">Product Category Parent<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

  <select class="form-control show-tick" name="parent_id" id="menu2">
               <option value="" Disabled selected> Select Type </option>
               <?php if($p_categories->count() > 0): ?>
                  <?php $__currentLoopData = $p_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorys): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(!empty($category->parent_id) && $category->parent_id== $categorys->id || collect(old('parent_id'))->contains($categorys->id)): ?>
                  <option value="<?php echo e($categorys->id); ?>" selected=""> <?php if($categorys->level=='0'): ?><?php echo e($categorys->name.'-Main Category'); ?> <?php elseif($categorys->level=='1'): ?> <?php echo e($categorys->name.'-'.$categorys->parent->name); ?> <?php else: ?> <?php echo e($categorys->name.'-'.$categorys->parent->parent->name); ?> <?php endif; ?> </option>
                  <?php else: ?>
                  <option value="<?php echo e($categorys->id); ?>">  <?php if($categorys->level=='0'): ?><?php echo e($categorys->name.'-Main Category'); ?> <?php elseif($categorys->level=='1'): ?> <?php echo e($categorys->name.'-'.$categorys->parent->name); ?> <?php else: ?> <?php echo e($categorys->name.'-'.$categorys->parent->parent->name); ?> <?php endif; ?>  </option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
            </select>
  </div>
</div>


<button type="submit" class="btn btn-primary"><?php echo e(isset($category) ? 'Update' : 'Create'); ?></button>
<a class="btn btn-dark" href="<?php echo e(route('product-category.index')); ?>">Cancel</a>

<script>
    $(document).ready(function () {
   
  
  $("#menu1").on("change", function(){ 
    var status = $(this).val(); 
     if (status==0)
       $("#Menu2Container").slideUp();
     else
      $("#Menu2Container").slideDown();
  });
});
</script>



<?php echo $__env->make('admin.common.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php /**PATH /home/baredesire/public_html/resources/views/admin/product-category/form.blade.php ENDPATH**/ ?>