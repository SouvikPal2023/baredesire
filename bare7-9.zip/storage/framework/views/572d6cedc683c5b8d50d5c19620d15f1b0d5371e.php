

<?php $__env->startSection('title', "Admin Profile"); ?>

<?php $__env->startSection('content'); ?>


<div class="row">
  <div class="col-xl-12">
    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Admin Profile</h5>
      </div>
      <div class="card-body">
        <form action="<?php echo e(route('changeAdminProfile')); ?>" method="POST" autocomplete="off" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="mb-3">
            <label class="form-label" for="Name">Full Name</label>
            <div class="input-group input-group-merge">
              <span id="basic-icon-default-fullname2" class="input-group-text"
                ><i class="bx bx-user"></i
              ></span>
              <input type="text"
              name="name"
              class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
              id="Name"
              placeholder="Account Name"
              value="<?php echo e(old('name', isset($adminUser->name) ? $adminUser->name:'')); ?>"
              required />
            </div>
          </div>
          
          <div class="mb-3">
            <label class="form-label" for="Email">Email</label>
            <div class="input-group input-group-merge">
              <span class="input-group-text"><i class="bx bx-envelope"></i></span>
              <input type="email"
              name="email"
              class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
              id="Email"
              placeholder="Email"
              value="<?php echo e(old('email', isset($adminUser->email) ? $adminUser->email:'')); ?>"
              required />
              
              
            </div>
            
          </div>
          <div class="mb-3">
            <div class="row">
              <div class="col-md-7">
                <label for="Image" class="form-label">Profile Image</label>
                <input type="file"
                name="image"
                accept="image/*"
                id="Image"
                class="form-control mb-4 <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
              </div>

              <div class="col-md-5">
                <img src="<?php echo e(isset($adminUser->image) ? config("app.url").Storage::url($adminUser->image) : asset('adminAssets/img/default-image.png')); ?>"
                id="SelectedImg"
                class="w-px-100 h-px-100 rounded-circle"
                title="Profile Image"
                alt="profile_image"
                style="object-fit: cover;">
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-primary">Update</button>
          <a class="btn btn-danger" href="<?php echo e(route('adminHome')); ?>">Cancel</a>
        </form>
      </div>
    </div>
  </div>
</div>



<?php echo $__env->make('admin.common.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/adminUser/adminUser.blade.php ENDPATH**/ ?>