

<?php $__env->startSection('title', 'Menu Config'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
    <?php echo Menu::render(); ?>

</div>

    <?php echo Menu::scripts(); ?>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/menu.blade.php ENDPATH**/ ?>