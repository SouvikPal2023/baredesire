

<?php $__env->startSection('title', 'Home Banners List'); ?>

<?php $__env->startSection('content'); ?>



<div class="content-wrapper">
  <div>
    <a href="<?php echo e(route('homeBanner.create')); ?>" class="btn btn-primary font-weight-bold mb-3">+ Add New Banner</a>
  </div>

  <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Home Banners List</h4>
          <hr>
        
          <div class="table-responsive  text-nowrap">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Image</th>
                  <th>Banner Title</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                <?php if($homeBanners->count() > 0 ): ?>
                  <?php $__currentLoopData = $homeBanners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $homeBanner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="py-1">
                        <img src="<?php echo e(isset($homeBanner->image) ? config("app.url").Storage::url($homeBanner->image) : asset('adminAssets/img/default-image.png')); ?>" alt="banner_image" class="w-px-50 h-px-50 rounded-circle"/>
                      </td>
                      <td>
                         <?php echo Str::limit($homeBanner->title, 50); ?>

                      </td>
                     
                      <td>
                         <div class="dropdown action-label">
                          <a class="btn dropdown-toggle btn-sm text-white <?php if(isset($homeBanner->status) && ($homeBanner->status=='active')): ?> btn-primary <?php else: ?> btn-danger <?php endif; ?>" data-bs-toggle="dropdown" aria-expanded="false">

                            <?=(isset($homeBanner->status) && $homeBanner->status=='active')?'<i class="fa fa-dot-circle-o text-success"></i> Active':'<i class="fa fa-dot-circle-o text-danger"></i> Inactive';?>

                            <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu">
                              <form action="<?php echo e(route('homeBanner.status', $homeBanner->id)); ?>" 
                                  method="POST" 
                                  >
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('PATCH'); ?>
                                   <button type="submit" 
                                        class="dropdown-item status-btn btn-sm" 
                                        style="cursor: pointer;">
                                    
                                    <?php echo ($homeBanner->status=='active')? "<i class='fa fa-dot-circle-o text-danger'></i> Inactive":"<i class='fa fa-dot-circle-o text-success'></i> Active"; ?>

                                  </button>
                              </form>
                            </div>
                        </div>
                      </td>
                      

                      <td>
                         <a href="<?php echo e(route('homeBanner.edit', $homeBanner)); ?>" class="btn btn-info btn-sm">
                           <i class='bx bx-edit-alt' ></i> Edit
                         </a>


                          <div class="d-inline-block">
                            <form action="<?php echo e(route('homeBanner.destroy', $homeBanner->id)); ?>" 
                              method="POST" 
                              >
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                               <button type="submit" 
                                    class="btn btn-danger btn-sm Delete" 
                                    style="cursor: pointer;">
                                
                                <i class='bx bxs-trash' ></i> Delete
                              </button>
                            </form>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <td colspan="5" class="text-center">No Banner Added Yet</td>
                <?php endif; ?>
               
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php echo $__env->make('admin.common.deleteConfirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/banner/homeBanner/list.blade.php ENDPATH**/ ?>