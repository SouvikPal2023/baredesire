
<div class="mb-3">
  <label class="form-label" for="Name">Size <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="size" 
           class="form-control <?php $__errorArgs = ['size'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="Name" 
           placeholder="Enter Size" 
           value="<?php echo e(old('size', isset($size->size) ? $size->size:'')); ?>" 
           required />
  </div>
</div>




<div class="mb-3">
  <label class="form-label" for="level">Product Type <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

  <select class="form-control show-tick" name="type">
                  <option value="" selected Disabled> Please Select Option </option>
                 
                  
                  <option value="bra" <?php echo e((!empty($size->type) && $size->type == 'bra') || old('type') == 'bra' ? 'selected' : ''); ?>> Bra </option>
                
                  <option value="others" <?php echo e((!empty($size->type) && $size->type == 'others') || old('type') == 'others' ? 'selected' : ''); ?>> Other Products </option>
                 
                 
                 
               </select>
  </div>
</div>













<button type="submit" class="btn btn-primary"><?php echo e(isset($size) ? 'Update' : 'Create'); ?></button>
<a class="btn btn-dark" href="<?php echo e(route('product-size.index')); ?>">Cancel</a>






<?php echo $__env->make('admin.common.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php /**PATH /home/baredesire/public_html/resources/views/admin/product-size/form.blade.php ENDPATH**/ ?>