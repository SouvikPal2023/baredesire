<div class="mb-3">
    <label class="form-label" for="FaqQuestion">Product Name<span class="text-danger">*</span></label>
    <div class="input-group input-group-merge">

     <input type="text"
             name="name"
             class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
             id="ProductName"
             placeholder="Enter Name"
             value="<?php echo e(old('name', isset($product->name) ? $product->name:'')); ?>"
             required />
    </div>
  </div>



  <div class="mb-3">
      <div class="row">
        <div class="col-md-7">
          <label for="ProfileImage" class="form-label">
            Image
          </label>
          <input type="file" name="product_image[]" accept="image/*" multiple="" id="ProductImage" onchange="showSelectedImage(this)" class="form-control <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
        </div>

        <div class="col-md-5">
        <?php if(isset($product->product_images)): ?>
         <?php $__currentLoopData = $product->product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       
         <img src="<?php echo e(isset($image->image) ? config("app.url").Storage::url($image->image) :asset('adminAssets/img/default-image.png')); ?>"
            width="100"
            height="100"
            class="round__custom rounded-circle"
            title="Product Image"
            alt="Product Image"
            style="margin-top: 20px;">
             <button class="btn btn-danger deleteImage" style="margin-top: 20px;" data-id="<?php echo e($image->id); ?>" title="Remove Image">X</button>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
        </div>
      </div>
    </div>


    <div class="mb-3" id="Menu2Container">
  <label class="form-label" for="level">Product Category<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

  <select class="form-control show-tick country" name="product_category_id[]" multiple>
                  <option value="" Disabled> Please Select Option </option>
                  <?php if($categories->count() > 0): ?>
                  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if((!empty($product->product_categories) && $product->product_categories->contains($category->id))|| collect(old('product_category_id'))->contains($category->id)): ?>
                  <option value="<?php echo e($category->id); ?>" selected=""> <?php echo e($category->name); ?> </option>
                  <?php else: ?>
                  <option value="<?php echo e($category->id); ?>"> <?php echo e($category->name); ?> </option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </select>
  </div>
</div>



<div class="mb-3">
  <label class="form-label" for="level">Product Size (For Bra only)<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

  <select class="form-control show-tick country" name="bra_size_id[]" multiple>>
                  <option value="" Disabled> Please Select Option </option>
                  <?php if($bra_sizes->count() > 0): ?>
                  <?php $__currentLoopData = $bra_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if((!empty($product->product_sizes) && $product->product_sizes->contains($size->id))|| collect(old('product_size_id'))->contains($size->id)): ?>
                  <option value="<?php echo e($size->id); ?>" selected> <?php echo e($size->size); ?> </option>
                  <?php else: ?>
                  <option value="<?php echo e($size->id); ?>"> <?php echo e($size->size); ?> </option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </select>
  </div>
</div>

<div class="mb-3">
  <label class="form-label" for="level">Product Size (For Other Products)<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

  <select class="form-control show-tick country" name="product_size_id[]" multiple>
                  <option value="" Disabled> Please Select Option </option>
                  <?php if($sizes->count() > 0): ?>
                  <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if((!empty($product->product_sizes) && $product->product_sizes->contains($size->id))|| collect(old('product_size_id'))->contains($size->id)): ?>
                  <option value="<?php echo e($size->id); ?>" selected> <?php echo e($size->size); ?> </option>
                  <?php else: ?>
                  <option value="<?php echo e($size->id); ?>"> <?php echo e($size->size); ?> </option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </select>
  </div>
</div>

<div class="mb-3" id="Menu2Container">
  <label class="form-label" for="level">Product Color<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

  <select class="form-control show-tick" name="color_id">
                  <option value="" Disabled selected> Please Select Option </option>
                  <?php if($colors->count() > 0): ?>
                  <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(!empty($product->color_id) && $product->color_id== $color->id || collect(old('color_id'))->contains($color->id)): ?>
                  <option value="<?php echo e($color->id); ?>" selected=""> <?php echo e($color->name); ?> </option>
                  <?php else: ?>
                  <option value="<?php echo e($color->id); ?>"> <?php echo e($color->name); ?> </option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </select>
  </div>
</div>

<div class="mb-3" id="Menu2Container">
  <label class="form-label" for="level">Product Variations<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

  <select class="form-control show-tick country" name="variation_id[]"
                    multiple="true" >
                  <option value="" Disabled> Please Select Option </option>
                  <?php if($prods->count() > 0): ?>
                  <?php $__currentLoopData = $prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if((!empty($product->variations) && $product->variations->contains($prod->id))|| collect(old('variation_id'))->contains($prod->id)): ?>
                  <option value="<?php echo e($prod->id); ?>" selected> <?php echo e($prod->name); ?> </option>
                  <?php else: ?>
                  <option value="<?php echo e($prod->id); ?>"> <?php echo e($prod->name); ?> </option>
                  <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
               </select>
  </div>
</div>
<div class="mb-3">
    <label class="form-label" for="FaqQuestion">Product Original price<span class="text-danger">*</span></label>
    <div class="input-group input-group-merge">

     <input type="text"
             name="original_price"
             class="form-control <?php $__errorArgs = ['original_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
             id="VideoCatName"
             placeholder="Enter Original Price"
             value="<?php echo e(old('original_price', isset($product->original_price) ? $product->original_price:'')); ?>"
             required />
    </div>
  </div>


  <div class="mb-3">
    <label class="form-label" for="FaqQuestion">Product Selling price<span class="text-danger">*</span></label>
    <div class="input-group input-group-merge">

     <input type="text"
             name="selling_price"
             class="form-control <?php $__errorArgs = ['selling_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
             id="VideoCatName"
             placeholder="Enter Selling Price"
             value="<?php echo e(old('selling_price', isset($product->selling_price) ? $product->selling_price:'')); ?>"
             required />
    </div>
  </div>

  <div class="mb-3">
    <label class="form-label" for="FaqQuestion">Product Description<span class="text-danger">*</span></label>
    <div class="input-group input-group-merge">

      <textarea rows="12" class="form-control no-resize Editor" name="description" placeholder="Description"><?php echo e(old('description') ?? ($product->description ?? '')); ?></textarea>
    </div>
  </div>

  <div class="mb-3">
    <label class="form-label" for="FaqQuestion">Product Wash Care<span class="text-danger">*</span></label>
    <div class="input-group input-group-merge">

      <textarea rows="12" class="form-control form-control
      
      
      
      no-resize Editor" name="wash" placeholder="Wash Care"><?php echo e(old('wash') ?? ($product->wash ?? '')); ?></textarea>
    </div>
  </div>


  <div class="mb-3">
    <label class="form-label" for="FaqQuestion">Product Additional Info<span class="text-danger">*</span></label>
    <div class="input-group input-group-merge">

      <textarea rows="12" class="form-control no-resize Editor" name="additional" placeholder="Additional Info"><?php echo e(old('additional') ?? ($product->additional ?? '')); ?></textarea>
    </div>
  </div>

  <button type="submit" class="btn btn-primary"><?php echo e(isset($product) ? 'Update' : 'Create'); ?></button>
  <a class="btn btn-dark" href="<?php echo e(route('product.index')); ?>">Cancel</a>




  <?php echo $__env->make('admin.common.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




  <script>
   $(function() {
         $('.deleteImage').on('click', function(e){
           e.preventDefault()
           let imageObj = $(this),
               image_id = imageObj.data('id'),
               url = '<?php echo e(route('product.removeImage')); ?>'
           if(confirm('Are you sure you want to delete this ?')) {
             $.ajax({
               headers: {
               'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
               },
               url: url,
               type: "DELETE",
               data: {'image_id':image_id},
   
               success: function(data) {
                   if (data.status == 200) {
                       imageObj.prev().remove()
                       imageObj.remove()
                       iziToast.success({
                           title: 'Success',
                           message: data.message,
                           position:'topCenter'
                       })
                   }
   
                   else{
                       iziToast.error({
                           title: 'Error',
                           message: data.message,
                           position:'topCenter'
                       });
                   }
               }
             });
           }
        });
   });
   
</script>
<script>
            $(document).ready(function () {
                //Select2
                $(".country").select2({
                    maximumSelectionLength: 9,
                });
                //Chosen
                $(".country1").chosen({
                    max_selected_options: 9,
                });
            });
        </script><?php /**PATH /home/baredesire/public_html/resources/views/admin/product/form.blade.php ENDPATH**/ ?>