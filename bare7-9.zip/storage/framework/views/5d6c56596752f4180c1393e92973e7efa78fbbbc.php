

<?php $__env->startSection('title', 'Testimonials'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  


  <div>
    <a href="<?php echo e(route('testimonial.create')); ?>" class="btn btn-primary font-weight-bold mb-3">
      + Add New Testimonial
    </a>
  </div>

  <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Testimonial List</h4>
          <hr>
        
          <div class="table-responsive">
            <table class="table table-striped">
              <thead>
                <tr>
                  <th>Image</th>
                  <th>Name</th>
                  <th>Designation</th>
                  <th>Testimonial</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                <?php if($testimonials->count() > 0 ): ?>
                  <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="py-1">
                        <img src="<?php echo e(isset($testimonial->image) ? config("app.url").Storage::url($testimonial->image) : asset('adminAssets/img/default-image.png')); ?>" alt="testimonial_image" class="w-px-50 h-px-50 rounded-circle"/>
                      </td>
                      <td>
                          <?php echo e($testimonial->name ?? '--'); ?>

                      </td>
                      <td>
                          <?php echo e($testimonial->designation ?? '--'); ?>

                      </td>
                      <td>
                          <?php echo Str::limit($testimonial->content, 50) ?? '--'; ?>

                      </td>
                      <td>
                         <div class="dropdown action-label">
                          <a class="btn <?php if(isset($testimonial->status) && ($testimonial->status=='active')): ?> btn-primary <?php else: ?> btn-danger <?php endif; ?> dropdown-toggle btn-sm text-white" data-bs-toggle="dropdown" aria-expanded="false">

                            <?=(isset($testimonial->status) && $testimonial->status=='active')?'<i class="fa fa-dot-circle-o text-success"></i> Active':'<i class="fa fa-dot-circle-o text-danger"></i> Inactive';?>

                            <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu">
                              <form action="<?php echo e(route('testimonial.status', $testimonial->id)); ?>" 
                                  method="POST" 
                                  >
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('PATCH'); ?>
                                   <button type="submit" 
                                        class="dropdown-item status-btn btn-sm" 
                                        style="cursor: pointer;">
                                    
                                    <?php echo ($testimonial->status=='active')? "<i class='fa fa-dot-circle-o text-danger'></i> Inactive":"<i class='fa fa-dot-circle-o text-success'></i> Active"; ?>

                                  </button>
                              </form>
                            </div>
                        </div>
                      </td>
                      <td>
                         <a href="<?php echo e(route('testimonial.edit', $testimonial)); ?>" class="btn btn-info btn-sm">
                          <i class='bx bx-edit-alt' ></i> Edit
                         </a>

                        <div class="d-inline-block">
                           <form action="<?php echo e(route('testimonial.destroy', $testimonial->id)); ?>" 
                              method="POST" 
                              >
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                               <button type="submit" 
                                    class="btn btn-danger btn-sm Delete" 
                                    style="cursor: pointer;">
                                
                                <i class='bx bxs-trash'></i> Delete
                              </button>
                          </form>
                          </div>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <td colspan="7" class="text-center">No Testimonial(s) Listed Yet</td>
                <?php endif; ?>
               
              </tbody>
            </table>

            <div class="mt-5">
              <?php echo e($testimonials->links('pagination::bootstrap-4')); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>


<?php echo $__env->make('admin.common.deleteConfirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/testimonialSection/list.blade.php ENDPATH**/ ?>