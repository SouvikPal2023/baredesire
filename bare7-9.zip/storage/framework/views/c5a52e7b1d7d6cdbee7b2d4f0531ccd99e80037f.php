

<?php $__env->startSection('title', "Edit Home Section8"); ?>

<?php $__env->startSection('content'); ?>



<div class="row">
  <div class="col-xl-12">
    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit Home Section8</h5>
      </div>
      <div class="card-body">
         <form class="forms-sample" 
               action="<?php echo e(route('homeSection8.update', $section)); ?>"
               method="POST" 
               autocomplete="off" 
               enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <?php echo $__env->make('admin.homeSection.section8.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </form>
      </div>
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/homeSection/section8/edit.blade.php ENDPATH**/ ?>