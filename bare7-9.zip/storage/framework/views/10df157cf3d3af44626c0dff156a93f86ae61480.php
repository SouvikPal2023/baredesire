
<?php $__env->startSection('title', "Product Detail"); ?>
<?php $__env->startSection('content'); ?>
<!-- banner-inner -->
<section class="detail-product-card">
    <div class="container-fluid">
        <div class="card-wrapper">
            <div class="card">
                <!-- card left -->
                <div id="sidebar">
                    <div class="product-imgs">
                        <div class="img-display">
                            <div class="img-showcase">
                                <?php $__currentLoopData = $product->product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img src="<?php echo e(isset($image->image) ? config("app.url").Storage::url($image->image) :asset('assets/images/logo.png')); ?>"
                                    alt="image" />
                                <!-- <img src="<?php echo e(asset('assets/images/ls1.jpg')); ?>" alt="shoe image" /> -->
                                <!-- <img src="<?php echo e(asset('assets/images/ls3.jpg')); ?>" alt="shoe image" />
                    <img src="<?php echo e(asset('assets/images/ls1.jpg')); ?>" alt="shoe image" />
                    <img src="<?php echo e(asset('assets/images/ls3.jpg')); ?>" alt="shoe image" /> -->
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <div class="img-select">
                            <?php
                            $i=1;
                            ?>
                            <?php $__currentLoopData = $product->product_images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="img-item">
                                <a href="#" data-id="<?php echo e($i++); ?>">
                                    <img src="<?php echo e(isset($image->image) ? config("app.url").Storage::url($image->image) :asset('assets/images/logo.png')); ?>"
                                        alt="image" />
                                </a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!-- <div class="img-item">
                    <a href="#" data-id="2">
                      <img src="<?php echo e(asset('assets/images/ls3.jpg')); ?>" alt="shoe image" />
                    </a>
                  </div>
                  <div class="img-item">
                    <a href="#" data-id="3">
                      <img src="<?php echo e(asset('assets/images/ls1.jpg')); ?>" alt="shoe image" />
                    </a>
                  </div>
                  <div class="img-item">
                    <a href="#" data-id="4">
                      <img src="<?php echo e(asset('assets/images/ls3.jpg')); ?>" alt="shoe image" />
                    </a>
                  </div> -->
                        </div>
                    </div>
                </div>
                <!-- card right -->
                <div class="product-content">
                    <h2 class="product-title"><?php echo e($product->name); ?></h2>
                    <!-- <a href="#" class="product-link">visit near store</a> -->
                    <div class="product-rating">
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <i class="fa fa-star" aria-hidden="true"></i>
                        <span>4.7(21)</span>
                    </div>
                    <?php
                    $price=($product->original_price -$product->selling_price);
                    $percent=($price/$product->original_price)*100;
                    ?>
                    <div class="product-price">
                        <p class="last-price">Old Price: <span>$<?php echo e($product->original_price); ?></span></p>
                        <p class="new-price">New Price: <span>$<?php echo e($product->selling_price); ?> (<?php echo e($percent); ?>%)</span></p>
                    </div>
                    <form action="<?php echo e(route('addToCart')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                      
                    <div id="available_sizes">
                            <p class="sizesAvailble prThumb">
                                <span style="text-align: left"> Available Sizes</span>
                            </p>

                            <input type="hidden" name="id"  value="<?php echo e($product->id); ?>" />
                            <ul class="free-selected size_mar listNone Sizeslist normal radio-button" id="selectSize1">
                                <?php
                                $i=1;
                                ?>
                                <?php $__currentLoopData = $product->product_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="radio" id="radio<?php echo e($i); ?>" name="size" value="<?php echo e($size->size); ?>">
                                <label for="radio<?php echo e($i); ?>"><?php echo e($size->size); ?></label>
                                <?php
                                $i++;
                                ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </ul>
                            <div id="requestSizeContainer"
                                class="productFilter size_mar productFilterLook2 col-lg-12 clearfix">
                                <p class="sizeChartRequest">
                                    <span style="display: flex">
                                        <a href="#" class="last" data-toggle="modal" data-target="#exampleModal">SIZE
                                            CHART</a>
                                    </span>

                                    <span class="sizeRequest">Couldn't find your size?<a href="#" class="pinkDark">
                                            Request your size here</a></span>
                                </p>
                            </div>
                        </div>

                        <div class="m-colors">
                            <h2>Choose Colors</h2>
                            <div class="c1">
                                <div class="radius-color">

                                    <div class="circle active" style="background-color:<?php echo e($product->color->code); ?>"></div>

                                    <?php $__currentLoopData = $product->variations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



                                    <a href="<?php echo e(route('productDetail',$variation->id)); ?>" target="_blank">
                                        <div class="circle" style="background-color:<?php echo e($variation->color->code); ?>"></div>
                                    </a>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>

                        <ul class="nav nav-tabs" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" href="#profile" role="tab" data-toggle="tab">Description</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nl1" href="#buzz" role="tab" data-toggle="tab">Wash</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link nl1" href="#references" role="tab" data-toggle="tab">
                                    Additional Info</a>
                            </li>
                        </ul>

                        <!-- Tab panes -->
                        <div class="tab-content product-details-tab">
                            <div role="tabpanel" class="tab-pane fade in active show" id="profile">
                                <div class="product-detail">
                                    <?php echo $product->description; ?>

                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="buzz">
                                <div class="prdetail">
                                    <?php echo $product->wash; ?>


                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane fade" id="references">
                                <div>
                                    <div class="prdetail prddetails_addinfo">
                                        <p>
                                            <?php echo $product->additional; ?>


                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="purchase-info">
                            <input type="number" name="quantity" min="1" max="10" value="1" />
                           
                            <button type="submit" class="btn">
                                Add to Cart
                                <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                            </button>
                           
                            <button type="button" class="btn">Buy Now</button>
                        </div>
                    </form>
                    <div class="estimate-delivery">
                        <h2>
                            <i class="fa fa-truck" aria-hidden="true"><span>Estimate Delivery</span></i>
                        </h2>
                        <div class="bnd">
                            <a href="#" class="bnd1">Shipping </a>
                            <a href="#" class="bnd1">Discreet Packaging </a>
                            <a href="#" class="bnd11"> Return Policy </a>
                        </div>
                        <form class="address-pincode">
                            <?php echo csrf_field(); ?>
                            <input class="pin" placeholder=" Enter Pincode" type="text" name="pincode" />
                            <button type="submit" class="btn">Check</button>
                           
                        </form><div id="pincode-message" class=""></div>
                    </div>

                    <section>
                        <div class="factor">
                            <p class="icns">
                                <span>
                                    <i class="fa fa-money" aria-hidden="true"></i>
                                </span>
                                <strong>COD Available</strong>
                            </p>
                            <p class="icns">
                                <span>
                                    <i class="fa fa-refresh" aria-hidden="true"></i>
                                </span>
                                <strong>15 days returns</strong>
                            </p>
                            <p class="icns">
                                <span>
                                    <i class="fa fa-truck" aria-hidden="true"></i>
                                </span>
                                <strong>Free shipping</strong>
                            </p>
                        </div>
                    </section>

                    <section class="rating">
                        <h2>Rating & Reviews</h2>
                        <div class="rating-list">
                            <div class="stars">
                                <i class="fa fa-star" aria-hidden="true" style="color: gold"></i>
                                <i class="fa fa-star" aria-hidden="true" style="color: gold"></i>
                                <i class="fa fa-star" aria-hidden="true" style="color: gold"></i>
                                <i class="fa fa-star" aria-hidden="true" style="color: gold"></i>

                                <i class="fa fa-star" aria-hidden="true"></i>
                            </div>

                            <div class="rating-star">
                                <div>
                                    <span>4.7 </span>
                                    <span class="rating-span1"> Based on Rating</span>
                                </div>
                                <a href="#" class="rating-btn"> RATE & REVIEW </a>
                            </div>
                        </div>
                    </section>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="more-like-wrap">
    <h2>Similar Products</h2>
    <div class="more-like">
        <div class="owl-carousel owl-theme" id="similar-products">
            <?php $__currentLoopData = $similar_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="item">
                <ul>
                    <li>
                        <a href="<?php echo e(route('productDetail',$similar->id)); ?>" class="product-img">
                            <img src="<?php echo e(isset($similar->product_images->first->image->image) ? config("app.url").Storage::url($similar->product_images->first->image->image) :asset('assets/images/logo.png')); ?>"
                                alt="owl1" />
                            <!-- <img src="<?php echo e(asset('assets/images/pr1.jpg')); ?>" alt="owl1" /> -->
                            <span><?php echo e($similar->name); ?></span>
                            <span> $ <?php echo e($similar->original_price); ?></span>
                        </a>
                    </li>
                </ul>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function() {
        $('.address-pincode').submit(function(e) {
            e.preventDefault(); // Prevent the form from submitting normally
            
            // Get the pincode entered by the user
            var pincode = $('input[name="pincode"]').val();

            // Make an AJAX request to check the pincode
            $.ajax({
                type: 'POST',
                url: '<?php echo e(route('pincode')); ?>', // Replace with your actual route URL
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    pincode: pincode
                },
                success: function(response) {
                    // Display the response message in the message div
                    console.log(response)
                   
                   if(response.status==404){
                    $('#pincode-message').html(response.message).removeClass('success-message').addClass('error-message');;
                   }else{
                    $('#pincode-message').html(response.message).removeClass('error-message').addClass('success-message');
                    
                   }
                      
                   
                },
                error: function() {
                    // Handle errors here, e.g., display an error message
                    $('#pincode-message').html('Error occurred while checking pincode.');
                }
            });
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/frontend/contents/product-detail.blade.php ENDPATH**/ ?>