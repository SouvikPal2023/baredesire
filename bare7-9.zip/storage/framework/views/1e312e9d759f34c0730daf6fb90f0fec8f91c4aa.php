

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>


<!-- Content -->


<div class="row">
    <div class="col-lg-12 mb-4 order-0">
        <div class="card">
            <div class="d-flex align-items-end row">
                <div class="col-sm-7">
                    <div class="card-body">
                        <h5 class="card-title text-primary">Welcome back, <?php echo e(auth()->user()->name ?? ''); ?>! 🎉</h5>
                        <p class="mb-4">
                            Congratulations you are logged in! Now you can manage your application's contents from <span class="fw-bold">Dashboard</span> easily.
                        </p>
                        <a href="<?php echo e(route('siteSetting.index')); ?>" class="btn btn-sm btn-outline-primary">Go to Settings</a>
                    </div>
                </div>
                <div class="col-sm-5 text-center text-sm-left">
                    <div class="card-body pb-0 px-0 px-md-4">
                        <img
                        src="<?php echo e(asset('adminAssets/img/illustrations/man-with-laptop-light.png')); ?>"
                        height="140"
                        alt="View Badge User"
                        />
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    

</div>

<!-- / Content -->

           
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>