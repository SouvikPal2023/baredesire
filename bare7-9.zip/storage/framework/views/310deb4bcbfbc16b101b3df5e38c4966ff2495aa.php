

<?php $__env->startSection('title', 'Login'); ?>

<?php $__env->startSection('content'); ?>



<div class="card">
  <div class="card-body">
    <!-- Logo -->
    <div class="app-brand justify-content-center">
      <a href="<?php echo e(route('admin.login')); ?>" class="app-brand-link gap-2">
        <span class="app-brand-logo demo">
          <img src="<?php echo e(isset($setting->site_logo) ? config("app.url").Storage::url($setting->site_logo) : asset('adminAssets/img/favicon/favicon.ico')); ?>" alt="logo" class="img-fluid my-2 w-px-200"/>
        </span>

       
      </a>
    </div>
    <!-- /Logo -->
    <h4 class="mb-2">Welcome to <?php echo e(isset($setting->site_name) ? $setting->site_name : env('APP_NAME')); ?>! 👋</h4>
    <p class="mb-4">Please sign-in to your account and start the adventure</p>
    <form id="formAuthentication" class="mb-3" action="<?php echo e(route('admin.login')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <div class="mb-3">
        <label for="Email" class="form-label">Email</label>
        
        <input type="email"
        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        id="Email"
        name="email"
        placeholder="Enter your email"
        autofocus
        required=""
        />
      </div>
      <div class="mb-3 form-password-toggle">
        <div class="d-flex justify-content-between">
          <label class="form-label" for="Password">Password</label>
        </div>
        <div class="input-group input-group-merge">
          <input type="password"
          class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
          id="Password"
          name="password"
          placeholder="&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;&#xb7;"
          required=""
          />
          <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
        </div>
      </div>
      <div class="mb-3">
        <div class="form-check">
          <input class="form-check-input" type="checkbox" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>/>
          <label class="form-check-label" for="remember"> Remember Me </label>
        </div>
      </div>
      <div class="mb-3">
        <button class="btn btn-primary d-grid w-100" type="submit">Sign in</button>
      </div>
    </form>
    <p class="text-center">
      Copyright &copy; <?php echo e(date('Y')); ?>  All rights reserved.
    </p>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.loginLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>