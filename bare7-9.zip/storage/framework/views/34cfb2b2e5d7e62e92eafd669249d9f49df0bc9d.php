<?php echo $__env->make('frontend.partials.headerCss', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('frontend.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- inner-banner -->
<section class="section breadcrumb-wrapper">
    <div class="shell">
        <h2>Order List</h2>
    </div>
</section>
<!-- inner-banner end -->

<section class="search-form">
    <div class="container">
        <form>
            <!--<div class="col-md-6">-->
            <!--    <div class="form-group d-flex order-search">-->
            <!--        <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Search Order">-->
            <!--        <a href="#"><i class="fa fa-search" aria-hidden="true"></i></a>-->
            <!--    </div>-->
            <!--</div>-->

        </form>
    </div>
</section>

<?php $__currentLoopData = $orderlists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="service-wrap order">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="service-box">
                    <div class="order-list-wrap">
                        <div class="container">
                            <div class="order-list-card">
                                <div class="row align-items-center">
                                    <div class="col-md-3">
                                        <p class="order-id"><span>Order id:</span><?php echo e($orderlist->order_number); ?></p>
                                    </div>
                                    <div class="col-md-3">
                                        <?php

                                        $carbonDate = \Carbon\Carbon::parse($orderlist->created_at);
                                        $new_date= $carbonDate->addDays(3);
                                        $dateOnly = $new_date->format('Y-m-d');
                                        ?>
                                        <p class="order-date"><span>Order Placed:</span><?php echo e($orderlist->created_at->format('Y-m-d')); ?></p>
                                    </div>
                                    <div class="col-md-3">
<?php if($orderlist->status=="order_placed"): ?>
                                        <p class="order-date"><span>Delivery
                                                Within:</span><?php echo e($dateOnly); ?></p>
                                                <?php elseif($orderlist->status =="cancelled"): ?><p class="order-date"><span>Order Status:</span>Cancelled</p><?php else: ?><p class="order-date"><span>Order Status:</span>Delivered</p>
                                                <?php endif; ?>
                                    </div>
                                    <div class="col-md-3">
                                        <a href="<?php echo e(route('orderdetail',$orderlist->id)); ?>" class="view-details">View
                                            Details</a>
                                    </div>

                                    <div class="col-md-12">
                                        <div class="order-list">
                                            <div class="order-list-details">
                                                <table class="table table-striped">
                                                    <tbody>
                                                        <?php
                                                        $i=1;
                                                        ?>
                                                        <?php $__currentLoopData = $orderlist->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php
                                                        $product=App\Models\Product::find($product->id);

                                                        ?>
                                                        <tr>
                                                            <td><?php echo e($i++); ?></td>
                                                            <td><a href="<?php echo e(route('productDetail',$product->id)); ?>"><img
                                                                        src="<?php echo e(isset($product->product_images->first->image->image) ? config("app.url").Storage::url($product->product_images->first->image->image) :asset('assets/images/fun2.jpg')); ?>"
                                                                        alt="owl1" /></a></td>
                                                            <td><?php echo e(Str::limit($product->name, 50)); ?></td>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <!-- <tr>
                  <td>2</td>
                  <td><a href="#"><img src="images/pr5.jpg" alt=""></a></td>
                  <td>Product Name</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td><a href="#"><img src="images/pr8.jpg" alt=""></a></td>
                  <td>Product Name</td>
                </tr>
                <tr>
                  <td>4</td>
                  <td><a href="#"><img src="images/pr7.jpg" alt=""></a></td>
                  <td>Product Name</td>
                </tr> -->
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php echo $__env->make('frontend.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('frontend.partials.footerScripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/frontend/contents/orderList.blade.php ENDPATH**/ ?>