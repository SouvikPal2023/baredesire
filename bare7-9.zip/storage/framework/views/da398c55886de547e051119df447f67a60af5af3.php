
<?php $__env->startSection('title', "Forget Password"); ?>
<?php $__env->startSection('content'); ?>

<section class="login-page-form">
  <div class="container">
    <div class="row align-items-center">

      <div class="col-md-12">
      <form class="rd-mailform1 text-center" action="<?php echo e(route('forget.password.post')); ?>" method="POST">
<?php echo csrf_field(); ?>
                <div class="row justify-content-center">
                  <div class="col-md-7">
                    <div class="rd-mailform-forget">
                      <h3 class="">Forget Password</h3>
                    <div class="form-group">
                      <input type="text" class="form-control" placeholder="Type Your Email... " name="email">
                    </div>
                    <div class="text-left">
                  <button class="contact_submit_btn" type="submit">Sumbmit</button>
                </div>
                    </div>
                  </div>
                  
                </div>
                
              </form>
      </div>
    </div>
  </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/frontend/contents/forgetPassword.blade.php ENDPATH**/ ?>