
<?php $__env->startSection('title', "Product Detail"); ?>
<?php $__env->startSection('content'); ?>
<!-- banner-inner -->
<section class="inner-banner">
    <div class="container-fluid">
        <div class="inner-header">
            <div class="inner-header-menu">
                <ul>
                    <li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('maincategory-product',$category->parent->parent->id)); ?>"><?php echo e($category->parent->parent->name); ?></a></li>
                    <li>
                        <p><?php echo e($category->name); ?></p>
                    </li>
                </ul>
            </div>
            <div class="product-heading">
                <h4><?php echo e($category->name); ?><span>(<?php echo e($data_count); ?> products)</span></h4>
            </div>
        </div>
        <div class="breadcrumb-2">
            <img src="<?php echo e(isset($category->banner_image) ? config("app.url").Storage::url($category->banner_image) : asset('assets/images/innerbanner1.jpg')); ?>"
                alt="">

            <div class="inner-content">
                <h3><?php echo e($category->name); ?></h3>

                <?php echo $category->description; ?>



            </div>
        </div>
    </div>
</section>
<!-- banner-inner-end -->
<!-- feature -->
<section class="feature">
    <div class="container">
        <div class="feature-wrap">
            <div class="row">
                <div class="col-md-4">
                    <div class="feature-wrap-box">
                        <a href="#">
                            <img src="<?php echo e(isset($section9->image1) ? config("app.url").Storage::url($section9->image1) :asset('assets/images/sticker1.png')); ?>"
                                alt="image" />
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-wrap-box">
                        <a href="#">
                            <img src="<?php echo e(isset($section9->image2) ? config("app.url").Storage::url($section9->image2) :asset('assets/images/sticker1.png')); ?>"
                                alt="image" />
                        </a>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="feature-wrap-box">
                        <a href="#">
                            <img src="<?php echo e(isset($section9->image3) ? config("app.url").Storage::url($section9->image3) :asset('assets/images/sticker1.png')); ?>"
                                alt="image" />
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- feature-end -->
<!-- collection -->
<section class="collection">
    <div class="container-fluid">

        <div class="product-wrap">
            <?php if($data_count !==0): ?>
            <?php
            $i=1;
            $j=1;
            ?>
            <?php $__currentLoopData = $categoryProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="product-wrap-box">
                <a href="<?php echo e(route('productDetail',$product->id)); ?>"><img
                        src="<?php echo e(isset($product->product_images->first->image->image) ? config("app.url").Storage::url($product->product_images->first->image->image) :asset('assets/images/pr1.jpg')); ?>"
                        alt="owl1" />

                    <h4><?php echo e(Str::limit($product->name, 30)); ?></h4>
                    <p>$<?php echo e($product->original_price); ?></p>
                </a>
                <div class="cart-button">
                    <a href="#" class="cart" data-target="#size-modal<?php echo e($i); ?>" data-toggle="modal">Add to cart</a>
                    <form action="<?php echo e(route('addToWish')); ?>" method="POST" enctype="multipart/form-data">
                      <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />
                    <button type="submit" class="buy">Add to Wishlist</button>
</form>
                </div>
                <div class="modal fade size-chart" id="size-modal<?php echo e($i); ?>" tabindex="-1" aria-hidden="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="size-modal<?php echo e($i); ?>">Select Size</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('addToCart')); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($product->id); ?>" />

                                    <input type="hidden" name="quantity" value="1" />
                                    <ul class="free-selected size_mar listNone Sizeslist normal radio-button"
                                        id="selectSize2">

                                        <?php $__currentLoopData = $product->product_sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <input type="radio" id="radio<?php echo e($j); ?>" name="size" value="<?php echo e($size->size); ?>">
                                        <label for="radio<?php echo e($j); ?>"><?php echo e($size->size); ?></label>

                                        <?php
                                        $j++;
                                        ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>

                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-primary">Go To Cart</button>
                                <!-- <button type="button" class="btn btn-primary">Submit</button> -->
                            </div>
                            </form>
                        </div>
                    </div>
                    <?php
                    $i++;
                    ?>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
             <div class="empty-cart"><p><?php echo e('No Products Found!'); ?></p></div>
            <?php endif; ?>
        
        </div>
    </div>
</section>
<!-- collection-head -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/frontend/contents/productInner.blade.php ENDPATH**/ ?>