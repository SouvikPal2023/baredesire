

<?php $__env->startSection('title', "Edit Social-Link"); ?>

<?php $__env->startSection('content'); ?>





<div class="row">
  <div class="col-xl-12">
    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Edit <?php echo e($socialLink->name); ?></h5>
      </div>
      <div class="card-body">
         <form class="forms-sample" 
               action="<?php echo e(route('socialLink.update', $socialLink)); ?>"
               method="POST" 
               autocomplete="off"
               enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <?php echo $__env->make('admin.socialLink.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </form>
      </div>
    </div>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/socialLink/edit.blade.php ENDPATH**/ ?>