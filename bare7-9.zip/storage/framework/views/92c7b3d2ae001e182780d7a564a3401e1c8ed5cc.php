
<?php $__env->startSection('title', "Cart View"); ?>
<?php $__env->startSection('content'); ?>
<!-- banner-inner -->
<section class="inner-banner">
    <div class="container-fluid">
        <div class="inner-header">
            <div class="inner-header-menu">
                <ul>
                    <li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('cartView')); ?>">Cart</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- banner-inner-end -->
<?php if($carts->isEmpty()): ?>


<div class="empty-cart"><p><?php echo e('Cart is empty!!'); ?></p></div>

<?php else: ?>
<section class="cart-section">
    <div class="container">
        <div class="cart-wrap">
            <form action="<?php echo e(route('removeCart')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="Delete Delete-1">Clear Cart<i class="fa fa-trash-o" aria-hidden="true"></i></button>
            </form>
            <div class="row">
                <div class="col-md-12 col-lg-8 col-xl-8">
                    <div class="cart-wrap-left">
                        <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                        <?php
                        $product=App\Models\Product::find($cart->product_id);

                        ?>
                        <div class="cart-wrap-box">
                            <div class="cart-wrap-box-img">

                                <a href="<?php echo e(route('productDetail',$product->id)); ?>"><img
                                        src="<?php echo e(isset($product->product_images->first->image->image) ? config("app.url").Storage::url($product->product_images->first->image->image) :asset('assets/images/fun2.jpg')); ?>"
                                        alt="owl1" /></a>
                            </div>
                            <div class="cart-wrap-box-content">
                                <p><span class="special"> <?php echo e(Str::limit($product->name, 50)); ?></span></p>
                                <p><span class="special">Size:</span> <?php echo e($cart->size ?? '--'); ?></p>
                                <ul class="cart-wrap-box-content-buttons myClass">
                                    <li>
                                        <p><span class="special">Qty:</span>
                                    
                                            <button class="decrease<?php echo e($product->id); ?>" id="d-<?php echo e($product->id); ?>"
                                                onclick="decrement(<?php echo e($product->id); ?>,<?php echo e($cart->id); ?>)" data-id="<?php echo e($cart->id); ?>"
                                                data-product="<?php echo e($product->id); ?>">-</button>
                                      
                                        <input class="quantity" id="demoInput<?php echo e($cart->id); ?>" type="number" value="<?php echo e($cart->quantity); ?>"
                                            min=1 max=10>
                                       
                                            <button class="increase<?php echo e($product->id); ?>" id="i-<?php echo e($product->id); ?>"
                                                onclick="increment(<?php echo e($product->id); ?>,<?php echo e($cart->id); ?>)" data-product="<?php echo e($product->id); ?>"
                                                data-id="<?php echo e($cart->id); ?>">+</button>
                                      

                                        </p>
                                    </li>
                                    <li>
                                        <form action="<?php echo e(route('saveLater',$cart->id)); ?> " method="POST">
                                            <?php echo csrf_field(); ?>

                                          
                                            <p><button type="submit" class="Confirm"><i class="fa fa-heart-o"
                                                        aria-hidden="true"></i>Save For
                                                    Later</button></p>
                                        </form>
                                    </li>
                                    <li>
                                        <form action="<?php echo e(route('removeItem',$cart->id)); ?> " method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <p><button type="submit" class="Delete"><i class="fa fa-trash-o"
                                                        aria-hidden="true"></i>Remove</button></p></form
                                    </li>
                                </ul>
                            </div>
                            <div>
                                <p class="price" id="price<?php echo e($cart->id); ?>">₹ <?php echo e($product->original_price * $cart->quantity); ?>.00</p>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- <div class="cart-wrap-box">
                <div class="cart-wrap-box-img">
                  <a href="#"><img src="<?php echo e(asset('assets/images/fun2.jpg')); ?>" alt=""></a>
                </div>
                <div class="cart-wrap-box-content">
                  <p>Low Impact Cotton Non-Padded Non-Wired Sports Bra in...</p>
                  <ul class="cart-wrap-box-content-buttons">
                    <li><p><span>Qty:</span><button onclick="decrement()">-</button> <input id=demoInput type=number min=1 max=99>
                      <button onclick="increment()">+</button>
                    </p></li>
                    <li><p><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i>Save For Later</a></p></li>
                    <li><p><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i>Remove</a></p></li>
                  </ul>
                </div>
                <div class="price">
                  <p>₹ 245.00</p>
                </div>
              </div>
              <div class="cart-wrap-box">
                <div class="cart-wrap-box-img">
                  <a href="#"><img src="<?php echo e(asset('assets/images/fun2.jpg')); ?>" alt=""></a>
                </div>
                <div class="cart-wrap-box-content">
                  <p>Low Impact Cotton Non-Padded Non-Wired Sports Bra in...</p>
                  <ul class="cart-wrap-box-content-buttons">
                    <li><p><span>Qty:</span><button onclick="decrement()">-</button> <input id=demoInput type=number min=1 max=99>
                      <button onclick="increment()">+</button>
                    </p></li>
                    <li><p><a href="#"><i class="fa fa-heart-o" aria-hidden="true"></i>Save For Later</a></p></li>
                    <li><p><a href="#"><i class="fa fa-trash-o" aria-hidden="true"></i>Remove</a></p></li>
                  </ul>
                </div>
                <div class="price">
                  <p>₹ 245.00</p>
                </div>
              </div> -->
                    </div>
                </div>
                
                <div class="col-md-12 col-lg-4 col-xl-4">
                    <form action="<?php echo e(route('postCart')); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="cart-wrap-right">
                        <div class="checkout-button">
                            <button type="submit" class="btn">Proceed to checkout</button>
                        </div>

                        <div class="payment-details">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Total</th>
                                        <th id="total">₹ <?php echo e($price ?? 00); ?>.00</th>
                                    </tr>
                                </thead>
                               
                                <tbody>
                                    <tr>
                                        <td>Discount</td>
                                        <td id="discount">₹ <?php echo e($discount ?? '00'); ?>.00</td>
                                    </tr>
                                    <tr class="special">
                                        <th>Sub Total</th>
                                        <th>₹ <?php echo e($price-$discount ?? '00'); ?>.00</th>
                                    </tr>
                                    <tr>
                                        <td>Estimated Tax</td>
                                        <td>₹ <?php echo e($tax ?? '00'); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Shipping Charge</td>
                                        <td>Free</td>
                                    </tr>
                                    <tr>
                                        <td><input type="checkbox"  id="giftWrap" name="giftWrap" value="yes"><label for="giftWrap"> Gift
                                                Wrap</label></td>
                                        <td>₹ 35</td>
                                    </tr>
                                    <tr>
                                        <td>Payble Amount</td>
                                        <td>₹<span id="payableAmount"> <?php echo e($price-$discount+$tax ?? '00'); ?></span></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <input type="hidden" name="total"  value="<?php echo e($price); ?>" />
                        <input type="hidden" name="discount"  value="<?php echo e($discount); ?>" />
                        <!-- <div class="offer-sec">
                            <p class="offer-heading">Offer</p>
                            <div class="d-flex align-items-baseline">
                                <p><img src="<?php echo e(asset('assets/images/discount.png')); ?>" alt="">Apply Coupon</p>
                                <p class="text-right"><a href="#">View Offers</a></p>
                            </div>
                            <div class="apply-form">
                                <input type="text" name="" placeholder="Have A Coupon? Type here">
                                <a href="#">Apply</a>
                            </div>
                        </div> -->
                        <div class="checkout-button mb-5">
                            <button type="submit" class="btn">Proceed to checkout</button>
                        </div>
                    </div>
                    </form>
                </div>

            </div>

        </div>

    </div>
</section>
<!-- collection-head -->

<?php endif; ?>



<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>
<script src="//ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
<script>
$('.Delete').on('click', function(e) {

    e.preventDefault();
    //alert(0);
    var single = $(this);

    iziToast.question({
        overlay: true,
        toastOnce: true,
        id: 'question',
        title: 'Hey',
        message: 'Are you sure you want to delete?',
        position: 'center',
        buttons: [
            ['<button><b>YES</b></button>', function(instance, toast) {

                instance.hide({
                    transitionOut: 'fadeOut'
                }, toast);

                single.closest("form").submit();


            }, true],
            ['<button>NO</button>', function(instance, toast) {

                instance.hide({
                    transitionOut: 'fadeOut'
                }, toast);

            }]
        ]
    });

});
</script>

<script>
$('.Confirm').on('click', function(e) {

    e.preventDefault();
    //alert(0);
    var single = $(this);

    iziToast.question({
        overlay: true,
        toastOnce: true,
        id: 'question',
        title: 'Hey',
        message: 'Do you want to add this product to wishlist?',
        position: 'center',
        buttons: [
            ['<button><b>YES</b></button>', function(instance, toast) {

                instance.hide({
                    transitionOut: 'fadeOut'
                }, toast);

                single.closest("form").submit();


            }, true],
            ['<button>NO</button>', function(instance, toast) {

                instance.hide({
                    transitionOut: 'fadeOut'
                }, toast);

            }]
        ]
    });

});
</script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<!-- <script>
    $(document).ready(function () {
        $('#giftWrap').change(function () {
            var giftWrapAmount = 35;
            var currentPayableAmount = parseFloat($('#payableAmount').text().replace('₹ ', ''));

            if ($(this).prop('checked')) {
                currentPayableAmount += giftWrapAmount;
            } else {
                currentPayableAmount -= giftWrapAmount;
            }

            $('#payableAmount').text(currentPayableAmount.toFixed(2));
        });
    });
</script> -->

<script>
    $(document).ready(function () {
        $('#giftWrap').click(function () {
            var payableAmount = parseFloat($('#payableAmount').text().replace('₹ ', ''));

            if ($(this).prop('checked')) {
                var newPayableAmount = payableAmount + 35;
                $('#payableAmount').text(newPayableAmount.toFixed(2));
                
                if (confirm('Do you want to add Rs 35 as Gift wrap amount to the payable amount?')) {
                    // Handle user confirmation here, if needed
                } else {
                    $(this).prop('checked', false);
                    $('#payableAmount').text(payableAmount.toFixed(2));
                }
            } else {
                var newPayableAmount = payableAmount - 35;
                $('#payableAmount').text( newPayableAmount.toFixed(2));
            }
        });
    });
</script> 

<script>
    function updateQuantity(cartId, newQuantity) {
        $.ajax({
            url: "<?php echo e(route('update.quantity')); ?>",
            method: "POST",
            data: {
                _token: "<?php echo e(csrf_token()); ?>",
                cart_id: cartId,
                quantity: newQuantity
            },
            success: function (data) {
                
                        console.log(data)
                        if (data.status == 200) {
                            window.location.reload();
                           // const quantitySpan = document.querySelector('#price'+data.cart);
                //const priceSpan = button.closest('.cart-wrap-box-content').siblings().find('.price');
               // quantitySpan.textContent = '$'+parseInt(data.price*data.quantity) +'.00';
                           
                        iziToast.success({
                            title: 'Success',
                            message: data.message,
                            position:'topCenter'
                        })
                    }else{
                        iziToast.error({
                            title: 'Error',
                            message: data.message,
                            position:'topCenter'
                        });
                    }
                    
            },
            error: function() {
                // Handle error case
            }
        });
    }
    function increment(productId, cartId) {
        var input = $('#demoInput' + cartId);
        var newQuantity = parseInt(input.val()) + 1;
        if (newQuantity <= 10) {
            // Update input field and quantity in the database
            input.val(newQuantity);
            updateQuantity(cartId, newQuantity);
        }
    }

    function decrement(productId, cartId) {
        var input = $('#demoInput' + cartId);
        var newQuantity = parseInt(input.val()) - 1;
        if (newQuantity >= 1) {
            // Update input field and quantity in the database
            input.val(newQuantity);
            updateQuantity(cartId, newQuantity);
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/frontend/contents/cartView.blade.php ENDPATH**/ ?>