
<div class="mb-3">
  <label class="form-label" for="Name">Name <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

    <input type="text" 
           name="name" 
           class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="Name" 
           placeholder="Enter Name" 
           value="<?php echo e(old('name', isset($color->name) ? $color->name:'')); ?>" 
           required />
  </div>
</div>



<div class="mb-3">
  <label class="form-label" for="Designation">Code</label>
  <div class="input-group input-group-merge">

      <input type="text" 
           name="code" 
           class="form-control <?php $__errorArgs = ['code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="code" 
           placeholder="Enter Color Code" 
           value="<?php echo e(old('code', isset($color->code) ? $color->code:'')); ?>" />

  </div>
</div>



<div class="mb-3">
  <div class="row">
    <div class="col-md-7">
      <label for="ProfileImage" class="form-label">
        Icon
      </label>
      <input type="file" name="icon" accept="image/*" id="ProfileImage" onchange="showSelectedImage(this)" class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" />
    </div>

    <div class="col-md-5">
        <img src="<?php echo e(isset($color->icon) ? config("app.url").Storage::url($color->icon) : asset('adminAssets/img/default-image.png')); ?>"
         id="SelectedImg"
         class="w-px-100 h-px-100 rounded-circle"
         title="Color Image"
         alt="Color_image">
    </div>
  </div>
</div>











<button type="submit" class="btn btn-primary"><?php echo e(isset($color) ? 'Update' : 'Create'); ?></button>
<a class="btn btn-dark" href="<?php echo e(route('color.index')); ?>">Cancel</a>






<?php echo $__env->make('admin.common.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php /**PATH /home/baredesire/public_html/resources/views/admin/color/form.blade.php ENDPATH**/ ?>