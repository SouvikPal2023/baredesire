<div class="mb-3">
  <label class="form-label" for="FaqQuestion">Question<span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">

   <input type="text" 
           name="question" 
           class="form-control <?php $__errorArgs = ['question'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
           id="FaqQuestion" 
           placeholder="Enter Question" 
           value="<?php echo e(old('question', isset($faq->question) ? $faq->question:'')); ?>" 
           required />
  </div>
</div>



<div class="mb-3">
  <label class="form-label" for="Answer">Answer <span class="text-danger">*</span></label>
  <div class="input-group input-group-merge">
    
    <textarea class="nicEdit form-control <?php $__errorArgs = ['answer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="4" name="answer" id="Answer" placeholder="Enter Answer"><?php echo e(old('answer', isset($faq->answer) ? $faq->answer:'')); ?></textarea>
  </div>
</div>


<button type="submit" class="btn btn-primary"><?php echo e(isset($faq) ? 'Update' : 'Create'); ?></button>
<a class="btn btn-dark" href="<?php echo e(route('faq.index')); ?>">Cancel</a>




<?php echo $__env->make('admin.common.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>




<?php /**PATH /home/baredesire/public_html/resources/views/admin/faq/form.blade.php ENDPATH**/ ?>