

<?php $__env->startSection('title', 'FAQ List'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">

  

  <div>
    <a href="<?php echo e(route('faq.create')); ?>" class="btn btn-primary font-weight-bold mb-3">+ Add New FAQ</a>
  </div>

  <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h3 class="card-title">FAQ List</h3>
          <hr>
        
          <div class="table-responsive">
            <table class="table table-striped FAQ_LIST">
              <thead>
                <tr>
                  <th>Question</th>
                  <th>Answer</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                  <?php $__empty_1 = true; $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <tr data-index="<?php echo e($faq->id); ?>" data-position="<?php echo e($faq->position); ?>">
                      <td>
                        <?php echo e($faq->question); ?>

                      </td>

                      <td>
                        <?php echo Str::limit($faq->answer, 400); ?>

                      </td>

                      <td>
                         <div class="dropdown action-label">
                          <a class="btn <?php if(isset($faq->status) && ($faq->status=='active')): ?> btn-primary <?php else: ?> btn-danger <?php endif; ?>  dropdown-toggle btn-sm text-white" data-bs-toggle="dropdown" aria-expanded="false">

                            <?=(isset($faq->status) && $faq->status=='active')?'<i class="fa fa-dot-circle-o text-success"></i> Active':'<i class="fa fa-dot-circle-o text-danger"></i> Inactive';?>

                            <span class="caret"></span>
                            </a>
                            <div class="dropdown-menu">
                              <form action="<?php echo e(route('faq.status', $faq->id)); ?>" 
                                  method="POST" 
                                  >
                                  <?php echo csrf_field(); ?>
                                  <?php echo method_field('PATCH'); ?>
                                   <button type="submit" 
                                        class="dropdown-item status-btn btn-sm" 
                                        style="cursor: pointer;">
                                    
                                    <?php echo ($faq->status=='active')? "<i class='fa fa-dot-circle-o text-danger'></i> Inactive":"<i class='fa fa-dot-circle-o text-success'></i> Active"; ?>

                                  </button>
                              </form>
                            </div>
                        </div>
                      </td>

                     
                      <td>
                        <a href="<?php echo e(route('faq.edit', $faq)); ?>" class="btn btn-info btn-sm">
                          <i class='bx bx-edit-alt' ></i> Edit
                        </a>

                        <div class="d-inline-block">
                           <form action="<?php echo e(route('faq.destroy', $faq->id)); ?>" 
                              method="POST" 
                              >
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                               <button type="submit" 
                                    class="btn btn-danger btn-sm Delete" 
                                    style="cursor: pointer;">
                                
                                <i class='bx bxs-trash'></i> Delete
                              </button>
                          </form>
                          </div>
                      </td>
                    </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                  <td colspan="4" class="text-center">No FAQ(s) Listed Yet</td>
                <?php endif; ?>
               
              </tbody>
            </table>

            <div class="mt-5">
              <?php echo e($faqs->links('pagination::bootstrap-4')); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


</div>












<?php echo $__env->make('admin.common.deleteConfirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/faq/list.blade.php ENDPATH**/ ?>