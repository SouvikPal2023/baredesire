


<h1>Forget Password Email</h1>
   
You can reset password from bellow link:
<a href="<?php echo e(route('reset.password', $token)); ?>">Reset Password</a>
<?php echo $__env->make('admin.layout.loginLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/auth/email/forgetPassword.blade.php ENDPATH**/ ?>