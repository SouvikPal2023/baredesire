
<?php $__env->startSection('title', "Order View"); ?>
<?php $__env->startSection('content'); ?>
<!-- banner-inner -->
<section class="inner-banner">
    <div class="container-fluid">
        <div class="inner-header">
            <div class="inner-header-menu">
                <ul>
                    <li><a href="<?php echo e(route('dashboard')); ?>">Home</a></li>
                    <li><a href="#">Cart</a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- banner-inner-end -->

<section class="cart-section order-details">
    <div class="container">
        <div class="cart-wrap">
            <div class="row">
                <div class="col-md-12 col-lg-8 col-xl-8">
                    <div class="cart-wrap-left">

                        <?php $__currentLoopData = $detail->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $product=App\Models\Product::find($prod->id);

                        ?>
                        <div class="cart-wrap-box">
                            <div class="cart-wrap-box-img">
                                <a href="<?php echo e(route('productDetail',$product->id)); ?>"><img
                                        src="<?php echo e(isset($product->product_images->first->image->image) ? config("app.url").Storage::url($product->product_images->first->image->image) :asset('assets/images/fun2.jpg')); ?>"
                                        alt="owl1" /></a>
                            </div>
                            <div class="cart-wrap-box-content">
                                <p><?php echo e(Str::limit($product->name, 50)); ?></p>
                                <div class="cart-wrap-box-content-detail">
                                    <p><span>Order No:</span> <?php echo e($detail->order_number); ?></p>
                                    <p><span>Qty:</span><?php echo e($detail->products()
    ->where('products.id', $prod->id)
    ->first()
    ->pivot
    ->quantity); ?></p>
                                    <p><span>Size:</span><?php echo e($detail->products()
    ->where('products.id', $prod->id)
    ->first()
    ->pivot
    ->size); ?></p>
                                    <p><span>Color:</span><?php echo e($product->color->name); ?></p>
                                </div>

                            </div>
                            <div class="price">
                                <p>₹ <?php echo e($detail->products()
    ->where('products.id', $prod->id)
    ->first()
    ->pivot
    ->subtotal); ?>.00</p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </div>
                </div>

                <div class="col-md-12 col-lg-4 col-xl-4">
                    <div class="cart-wrap-right">
                        <div class="payment-details order-details-price">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Total</th>
                                        <th>₹ <?php echo e($price); ?>.00</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    <tr>
                                        <td>Discount</td>
                                        <td>₹ <?php echo e($discount); ?>.00</td>
                                    </tr>
                                    <tr>
                                        <th>Sub Total</th>
                                        <th>₹ <?php echo e($price-$discount); ?>.00</th>
                                    </tr>
                                    <tr>
                                        <td>Estimated Tax</td>
                                        <td>₹ <?php echo e($tax); ?>.00</td>
                                    </tr>
                                    <tr>
                                        <td>Shipping Charge</td>
                                        <td>Free</td>
                                    </tr>
                                    <tr>
                                        <td> Gift
                                            Wrap</td>
                                        <?php if($detail->total_price > ($price-$discount+$tax)): ?>
                                        <td>₹ 35.00</td>
                                        <?php else: ?>
                                        <td>₹ 00.00</td>
                                        <?php endif; ?>
                                    </tr>
                                    <tr>
                                        <td>Payble Amount</td>
                                        <td>₹<?php echo e($detail->total_price); ?>.00</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
                <div class="col-md-12 col-lg-12 col-xl-12">
                    <div class="order-status">
                        <h3 class="text-center">Order Detail</h3>

                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <div class="order-list-status">
                                    <p><span>Order Placed:</span><?php echo e($detail->created_at->format('Y-m-d')); ?><i
                                            class="fa fa-check-circle-o" aria-hidden="true"></i>
                                    </p>
                                    <p><span>Estemated
                                            Delivery:</span><?php echo e($detail->created_at->addDays(3)->format('Y-m-d')); ?><i
                                            class="fa fa-check-circle-o" aria-hidden="true"></i>
                                    </p>
                                    <?php if($detail->status == 'order_placed'): ?>
                                    <p><span>Order Status:</span>Order Placed<i class="fa fa-check-circle-o"
                                            aria-hidden="true"></i>

                                    </p>
                                    <?php elseif($detail->status == 'in_transit'): ?>
                                    <p><span>Order Status:</span>In Transit <i class="fa fa-spinner"
                                            aria-hidden="true"></i>


                                    </p>
                                    <?php elseif($detail->status == 'completed'): ?>
                                    <p><span>Order Status:</span>Delivered <i class="fa fa-check-circle"
                                            aria-hidden="true"></i>

                                    </p>
                                    <?php else: ?>
                                    <p><span>Order Status:</span>Cancelled
                                        <i class="fa fa-times" aria-hidden="true"></i>

                                    </p>
                                    <?php endif; ?>
                                    <p><span>Payment
                                            Mode:</span><?php echo e(isset($detail->payment_method) && $detail->payment_method=='cod'? 'Cash on Delivery(COD)':""); ?>

                                    </p>
                                    <?php if($detail->payment_status == 'pending'): ?>
                                    <p><span>Payment Status:</span>Pending <i class="fa fa-spinner"
                                            aria-hidden="true"></i>
                                    </p>
                                    <?php elseif($detail->payment_status == 'confirmed'): ?>
                                    <p><span>Payment Status:</span>Paid<i class="fa fa-check-circle-o"
                                            aria-hidden="true"></i>


                                    </p>
                                    <?php else: ?>
                                    <p><span>Payment Status:</span>Cancelled
                                        <i class="fa fa-times" aria-hidden="true"></i>

                                    </p>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <?php if($detail->status== 'order_placed'): ?>
                                <div class="cancel-order">
                                    <a href="#" data-target="#size-modal1" data-toggle="modal">Cancel Order</a>
                                </div>
                                <?php endif; ?>

                                <?php if($detail->status== 'cancelled'): ?>
                                <div class="cancel">
                                  <?php 
                                $carbonDate = \Carbon\Carbon::parse($detail->cancelled_at);
                                        
                                        $dateOnly = $carbonDate->format('Y-m-d');
                                        ?>
                                    <p><span>Order cancelled on:</span><?php echo e($dateOnly); ?></p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="modal fade size-chart" id="size-modal1" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="size-modal1">Are you sure about cancelling this order?</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('cancel.order',$detail->id)); ?>" method="POST"
                            enctype="multipart/form-data">

                            <?php echo csrf_field(); ?>
                            <textarea rows="12" class="form-control form-control
      
      
      
      no-resize" name="notes" placeholder="Mention Reason for your cancellation!(Optional)"></textarea>

                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-primary">Submit</button>
                        <button type="button" data-dismiss="modal" class="btn btn-primary">Back</button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/frontend/contents/orderDetail.blade.php ENDPATH**/ ?>