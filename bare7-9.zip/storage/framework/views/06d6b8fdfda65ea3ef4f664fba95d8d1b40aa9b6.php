

<?php $__env->startSection('title', 'Home Section 9'); ?>

<?php $__env->startSection('content'); ?>

<div class="content-wrapper">
  


  <div>
    <a href="<?php echo e(route('homeSection9.create')); ?>" class="btn btn-primary font-weight-bold mb-3">
      + Add New Section
    </a>
  </div>

  <div class="row">
    <div class="col-lg-12 grid-margin stretch-card">
      <div class="card">
        <div class="card-body">
          <h4 class="card-title">Home Section 9 Content</h4>
          <hr>
        
          <div class="table-responsive">
            <table class="table table-striped FAQ_LIST <?php echo count($sections)?'dataTable':'';?>">
              <thead>
                <tr>
                 
                  <th>Name</th>
                
                 
                  
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>
                <?php if($sections->count() > 0 ): ?>
                  <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td class="py-1">
                       <?php echo e("Home Section 9"); ?>

                     
                      <td>
                         <a href="<?php echo e(route('homeSection9.edit', $section)); ?>" class="btn btn-info btn-sm">
                          <i class='bx bx-edit-alt' ></i> Edit
                         </a>

                        <!-- <div class="d-inline-block">
                           <form action="<?php echo e(route('homeSection1.destroy', $section->id)); ?>" 
                              method="POST" 
                              >
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('DELETE'); ?>
                               <button type="submit" 
                                    class="btn btn-danger btn-sm Delete" 
                                    style="cursor: pointer;">
                                
                                <i class='bx bxs-trash'></i> Delete
                              </button>
                          </form>
                          </div> -->
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                  <td colspan="2" class="text-center">No Section(s) Listed Yet</td>
                <?php endif; ?>
               
              </tbody>
            </table>

            
          </div>
        </div>
      </div>
    </div>
  </div>

</div>


<?php echo $__env->make('admin.common.deleteConfirm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.adminMasterLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/baredesire/public_html/resources/views/admin/homeSection/section9/list.blade.php ENDPATH**/ ?>